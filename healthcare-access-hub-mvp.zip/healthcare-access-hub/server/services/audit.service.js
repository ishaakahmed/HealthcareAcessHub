import AuditLog from '../models/AuditLog.js';

/**
 * Records a security/admin-relevant action. Failures here are logged but
 * never allowed to break the calling request - an audit-log write problem
 * should not prevent, say, an admin from actually verifying a resource.
 */
export async function logAction({ actor, action, targetType, targetId, metadata, req }) {
  try {
    await AuditLog.create({
      actor: actor || null,
      action,
      targetType,
      targetId: targetId || null,
      metadata,
      ipAddress: req?.ip,
    });
  } catch (err) {
    console.error('Failed to write audit log:', err.message);
  }
}
