import { fail } from '../utils/apiResponse.js';
import { REPORT_REASON } from '../../shared/enums.js';

export function validateReportInput(req, res, next) {
  const { reason, details } = req.body;

  if (!reason || !Object.values(REPORT_REASON).includes(reason)) {
    return fail(res, 400, 'A valid report reason is required.');
  }
  if (details && (typeof details !== 'string' || details.length > 500)) {
    return fail(res, 400, 'Details must be 500 characters or fewer.');
  }

  next();
}
