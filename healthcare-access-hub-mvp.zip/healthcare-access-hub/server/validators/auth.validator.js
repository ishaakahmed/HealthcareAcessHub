import validator from 'validator';
import { fail } from '../utils/apiResponse.js';

export function validateRegister(req, res, next) {
  const { name, email, password } = req.body;

  if (!name || typeof name !== 'string' || name.trim().length < 2) {
    return fail(res, 400, 'Please provide a valid name.');
  }
  if (!email || !validator.isEmail(email)) {
    return fail(res, 400, 'Please provide a valid email address.');
  }
  if (!password || typeof password !== 'string' || password.length < 8) {
    return fail(res, 400, 'Password must be at least 8 characters long.');
  }

  req.body.name = validator.escape(name.trim());
  req.body.email = validator.normalizeEmail(email);
  next();
}

export function validateLogin(req, res, next) {
  const { email, password } = req.body;

  if (!email || !validator.isEmail(email)) {
    return fail(res, 400, 'Please provide a valid email address.');
  }
  if (!password || typeof password !== 'string') {
    return fail(res, 400, 'Please provide your password.');
  }

  req.body.email = validator.normalizeEmail(email);
  next();
}
