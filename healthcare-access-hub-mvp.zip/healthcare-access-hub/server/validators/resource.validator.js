import validator from 'validator';
import mongoose from 'mongoose';
import { fail } from '../utils/apiResponse.js';
import { COST_CATEGORY } from '../../shared/enums.js';

export function validateResourceInput(req, res, next) {
  const { name, category, description, costCategory, website } = req.body;

  if (!name || typeof name !== 'string' || name.trim().length < 2) {
    return fail(res, 400, 'Resource name is required.');
  }
  if (!category || !mongoose.isValidObjectId(category)) {
    return fail(res, 400, 'A valid category is required.');
  }
  if (!description || typeof description !== 'string' || description.trim().length < 10) {
    return fail(res, 400, 'A description of at least 10 characters is required.');
  }
  if (!costCategory || !Object.values(COST_CATEGORY).includes(costCategory)) {
    return fail(res, 400, 'A valid cost category is required.');
  }
  if (website && !validator.isURL(website, { require_protocol: true })) {
    return fail(res, 400, 'Website must be a valid URL (including https://).');
  }

  req.body.name = validator.escape(name.trim());
  req.body.description = validator.escape(description.trim());
  next();
}

export function validateObjectIdParam(paramName) {
  return (req, res, next) => {
    if (!mongoose.isValidObjectId(req.params[paramName])) {
      return fail(res, 400, `Invalid ${paramName}.`);
    }
    next();
  };
}
