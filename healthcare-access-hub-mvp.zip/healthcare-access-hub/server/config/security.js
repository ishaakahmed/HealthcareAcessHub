import rateLimit from 'express-rate-limit';

/**
 * Central place for security-related *configuration* (not the middleware
 * wiring itself - see middleware/security.middleware.js for that).
 * Keeping the settings here means Phase-3 auth work and later admin work
 * can reuse the same limiter definitions without duplicating numbers.
 */

/**
 * CORS options: only the configured frontend origin(s) may call this API.
 * CLIENT_ORIGIN can be a comma-separated list if you ever need more than one
 * (e.g. a deployed frontend URL plus a local dev URL).
 */
export function getCorsOptions() {
  const allowedOrigins = (process.env.CLIENT_ORIGIN || '')
    .split(',')
    .map((origin) => origin.trim())
    .filter(Boolean);

  return {
    origin(origin, callback) {
      // Allow requests with no origin (e.g. curl, server-to-server health checks)
      if (!origin || allowedOrigins.includes(origin)) {
        callback(null, true);
      } else {
        callback(new Error('Not allowed by CORS'));
      }
    },
    credentials: true, // required so the browser will send/receive auth cookies later
  };
}

/**
 * A generous global rate limit, applied to the whole API as a baseline
 * defense against abuse/scraping.
 */
export const globalRateLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 300,
  standardHeaders: true,
  legacyHeaders: false,
  message: {
    success: false,
    error: 'Too many requests. Please try again later.',
  },
});

/**
 * A much stricter limiter reserved for authentication endpoints
 * (login/register) once Phase 3 adds them - this is the primary
 * defense against brute-force and credential-stuffing attempts.
 */
export const authRateLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 10,
  standardHeaders: true,
  legacyHeaders: false,
  message: {
    success: false,
    error: 'Too many attempts. Please wait before trying again.',
  },
});
