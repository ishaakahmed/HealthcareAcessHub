import mongoose from 'mongoose';

/**
 * Connects to MongoDB using the connection string from environment variables.
 * We fail loudly (and exit) if the connection cannot be established, rather
 * than letting the server start in a broken state.
 */
export async function connectDB() {
  const uri = process.env.MONGO_URI;

  if (!uri) {
    console.error('MONGO_URI is not set. Check your .env file.');
    process.exit(1);
  }

  try {
    await mongoose.connect(uri);
    console.log('MongoDB connected successfully.');
  } catch (error) {
    // Never leak internal connection details to end users - this only
    // ever gets logged server-side, never sent in an HTTP response.
    console.error('MongoDB connection failed:', error.message);
    process.exit(1);
  }
}
