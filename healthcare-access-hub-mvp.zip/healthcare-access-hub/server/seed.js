/**
 * Seeds the database with clearly-labelled DEMO data: categories, a
 * handful of sample resources, a couple of "Explain Simply" articles,
 * one emergency contact placeholder, and two demo accounts (admin + member).
 *
 * This is NOT real healthcare provider data. Every seeded resource has
 * isDemoData: true and generic, obviously-fake contact details.
 *
 * Run with: npm run seed  (from /server, after .env is configured)
 */
import 'dotenv/config';
import bcrypt from 'bcryptjs';
import mongoose from 'mongoose';
import { connectDB } from './config/db.js';
import User from './models/User.js';
import HealthcareCategory from './models/HealthcareCategory.js';
import HealthcareResource from './models/HealthcareResource.js';
import HealthcareArticle from './models/HealthcareArticle.js';
import EmergencyResource from './models/EmergencyResource.js';
import { ROLES, VERIFICATION_STATUS, COST_CATEGORY } from '../shared/enums.js';

const CATEGORIES = [
  { name: 'General Physician', slug: 'general-physician', description: 'General check-ups and common illnesses.' },
  { name: 'Mental Health', slug: 'mental-health', description: 'Counselling and mental health support.' },
  { name: 'Medicine Information', slug: 'medicine-information', description: 'Pharmacies and medicine-related help.' },
  { name: 'Diagnostic & Lab Services', slug: 'diagnostic-lab', description: 'Blood tests and diagnostic imaging.' },
  { name: 'Maternal & Child Healthcare', slug: 'maternal-child', description: 'Pregnancy, newborn, and child health.' },
  { name: 'Elderly Care', slug: 'elderly-care', description: 'Services focused on elderly community members.' },
  { name: 'Vaccination', slug: 'vaccination', description: 'Immunization information and services.' },
  { name: 'Government & Community Assistance', slug: 'government-community', description: 'Public and NGO-run healthcare programs.' },
];

async function seed() {
  await connectDB();

  console.log('Clearing existing demo-flagged data...');
  await HealthcareResource.deleteMany({ isDemoData: true });
  await HealthcareCategory.deleteMany({});
  await HealthcareArticle.deleteMany({});
  await EmergencyResource.deleteMany({});

  console.log('Seeding categories...');
  const categories = await HealthcareCategory.insertMany(CATEGORIES);
  const bySlug = Object.fromEntries(categories.map((c) => [c.slug, c]));

  console.log('Seeding demo resources...');
  await HealthcareResource.insertMany([
    {
      name: '[DEMO] Community Health Clinic',
      category: bySlug['general-physician']._id,
      description: 'Sample general physician clinic used for demo purposes only. Not a real provider.',
      services: ['General check-ups', 'Basic consultations'],
      address: '123 Demo Street, Sample City',
      phone: '000-000-0000',
      website: 'https://example.com',
      isOnline: false,
      hours: 'Mon-Sat 9am-5pm',
      costCategory: COST_CATEGORY.LOW_COST,
      languagesSupported: ['English', 'Hindi'],
      verificationStatus: VERIFICATION_STATUS.VERIFIED,
      isDemoData: true,
    },
    {
      name: '[DEMO] Mann Sahaara Mental Health Line',
      category: bySlug['mental-health']._id,
      description: 'Sample free telehealth mental-health support line, for demo purposes only.',
      services: ['Phone counselling', 'Online sessions'],
      phone: '000-111-2222',
      isOnline: true,
      hours: '24/7',
      costCategory: COST_CATEGORY.FREE,
      languagesSupported: ['English', 'Hindi', 'Marathi'],
      verificationStatus: VERIFICATION_STATUS.VERIFIED,
      isDemoData: true,
    },
    {
      name: '[DEMO] City Diagnostic Lab',
      category: bySlug['diagnostic-lab']._id,
      description: 'Sample diagnostic lab offering blood tests, for demo purposes only.',
      services: ['Blood tests', 'X-ray'],
      address: '45 Sample Avenue, Demo City',
      phone: '000-333-4444',
      costCategory: COST_CATEGORY.INSURANCE_SUPPORTED,
      verificationStatus: VERIFICATION_STATUS.PENDING_VERIFICATION,
      isDemoData: true,
    },
    {
      name: '[DEMO] Community Vaccination Camp',
      category: bySlug['vaccination']._id,
      description: 'Sample government-supported vaccination drive, for demo purposes only.',
      services: ['Routine immunization'],
      address: 'Sample Community Hall, Demo City',
      costCategory: COST_CATEGORY.GOVERNMENT_SUPPORTED,
      verificationStatus: VERIFICATION_STATUS.COMMUNITY_SUBMITTED,
      isDemoData: true,
    },
  ]);

  console.log('Seeding "Explain Simply" articles...');
  await HealthcareArticle.insertMany([
    {
      term: 'Hypertension',
      simpleExplanation: 'High blood pressure. It means the pressure of blood against your blood vessels is higher than it should be.',
      whyItMatters: 'Over time, unmanaged high blood pressure can strain your heart and blood vessels.',
      warningSigns: ['severe headache', 'chest pain', 'difficulty breathing'],
      category: bySlug['general-physician']._id,
    },
    {
      term: 'Anemia',
      simpleExplanation: 'A condition where your blood has fewer healthy red blood cells than normal, which can make you feel tired.',
      whyItMatters: 'It can affect energy levels and overall health if left unaddressed.',
      warningSigns: ['extreme fatigue', 'pale skin', 'shortness of breath'],
      category: bySlug['general-physician']._id,
    },
  ]);

  console.log('Seeding a placeholder emergency contact...');
  await EmergencyResource.create({
    region: 'Sample Region (replace with real local number)',
    serviceName: 'Local Emergency Services',
    phone: '112',
    notes: 'Placeholder - an administrator should verify and update this for the actual deployment region.',
  });

  console.log('Seeding demo accounts (admin + member)...');
  const existingAdmin = await User.findOne({ email: 'admin@demo.local' });
  if (!existingAdmin) {
    await User.create({
      name: 'Demo Admin',
      email: 'admin@demo.local',
      passwordHash: await bcrypt.hash('DemoAdmin123!', 12),
      role: ROLES.ADMIN,
    });
  }
  const existingMember = await User.findOne({ email: 'member@demo.local' });
  if (!existingMember) {
    await User.create({
      name: 'Demo Member',
      email: 'member@demo.local',
      passwordHash: await bcrypt.hash('DemoMember123!', 12),
      role: ROLES.MEMBER,
    });
  }

  console.log('Seed complete.');
  await mongoose.disconnect();
  process.exit(0);
}

seed().catch((err) => {
  console.error('Seed failed:', err);
  process.exit(1);
});
