import { logAction } from '../services/audit.service.js';

/**
 * Convenience middleware factory: logs a fixed action after the response
 * has been sent, using whatever req.auditTarget the controller set.
 * For actions needing custom metadata, controllers can instead call
 * services/audit.service.js's logAction() directly - both patterns write
 * to the same AuditLog collection.
 */
export function auditAction(action) {
  return (req, res, next) => {
    res.on('finish', () => {
      if (res.statusCode < 400) {
        logAction({
          actor: req.user?._id,
          action,
          targetType: req.auditTarget?.type,
          targetId: req.auditTarget?.id,
          metadata: req.auditTarget?.metadata,
          req,
        });
      }
    });
    next();
  };
}
