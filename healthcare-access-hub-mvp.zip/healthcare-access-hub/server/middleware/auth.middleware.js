import jwt from 'jsonwebtoken';
import User from '../models/User.js';
import { fail } from '../utils/apiResponse.js';

/**
 * Reads the JWT from the httpOnly cookie, verifies it, and attaches the
 * corresponding user to req.user. Never trusts anything the client claims
 * about its own identity/role beyond what's in the signed token.
 */
export async function requireAuth(req, res, next) {
  const token = req.cookies?.token;

  if (!token) {
    return fail(res, 401, 'You must be logged in to do that.');
  }

  try {
    const payload = jwt.verify(token, process.env.JWT_SECRET);
    const user = await User.findById(payload.sub);

    if (!user) {
      return fail(res, 401, 'Your session is no longer valid. Please log in again.');
    }

    req.user = user;
    next();
  } catch (err) {
    return fail(res, 401, 'Your session has expired. Please log in again.');
  }
}

/**
 * Like requireAuth, but does not fail the request if there's no valid
 * session - it just leaves req.user unset. Useful for routes that behave
 * slightly differently for logged-in users but are also public.
 */
export async function attachUserIfPresent(req, _res, next) {
  const token = req.cookies?.token;
  if (!token) return next();

  try {
    const payload = jwt.verify(token, process.env.JWT_SECRET);
    const user = await User.findById(payload.sub);
    if (user) req.user = user;
  } catch {
    // Invalid/expired token on an optional-auth route - just proceed as a guest.
  }
  next();
}
