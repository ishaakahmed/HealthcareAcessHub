import helmet from 'helmet';
import cors from 'cors';
import mongoSanitize from 'express-mongo-sanitize';
import { getCorsOptions, globalRateLimiter } from '../config/security.js';

/**
 * Applies the baseline security middleware stack to the Express app.
 * Called once from server.js, before any routes are mounted.
 *
 * Deliberately kept small: only what this project actually needs at
 * this stage. We add more (e.g. stricter CSP rules) only when a real
 * feature requires it.
 */
export function applySecurityMiddleware(app) {
  // Sets a sensible set of protective HTTP headers.
  app.use(helmet());

  // Only the configured frontend origin(s) may call this API.
  app.use(cors(getCorsOptions()));

  // Strips out any keys starting with "$" or containing "." from
  // req.body/req.query/req.params, preventing MongoDB operator injection.
  app.use(mongoSanitize());

  // Baseline request-rate protection for the whole API.
  app.use(globalRateLimiter);
}
