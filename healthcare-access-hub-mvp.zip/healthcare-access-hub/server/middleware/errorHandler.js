/**
 * Centralized error handler. Must be registered LAST, after all routes.
 *
 * Rule: the client only ever sees a short, friendly message. Full error
 * details (stack trace, etc.) are logged server-side only.
 */
export function errorHandler(err, req, res, _next) {
  console.error('Unhandled error:', err.stack || err.message || err);

  const status = err.status || 500;
  const isProduction = process.env.NODE_ENV === 'production';

  res.status(status).json({
    success: false,
    error: isProduction
      ? 'Something went wrong. Please try again.'
      : err.message || 'Something went wrong. Please try again.',
  });
}

/**
 * Catches requests to routes that don't exist.
 */
export function notFoundHandler(req, res) {
  res.status(404).json({
    success: false,
    error: 'The requested resource was not found.',
  });
}
