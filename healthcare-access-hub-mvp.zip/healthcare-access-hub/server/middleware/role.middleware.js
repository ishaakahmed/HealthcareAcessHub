import { fail } from '../utils/apiResponse.js';

/**
 * Restricts a route to specific roles. Must run AFTER requireAuth.
 * Usage: router.post('/x', requireAuth, requireRole('admin'), handler)
 */
export function requireRole(...allowedRoles) {
  return (req, res, next) => {
    if (!req.user) {
      return fail(res, 401, 'You must be logged in to do that.');
    }
    if (!allowedRoles.includes(req.user.role)) {
      return fail(res, 403, 'You do not have permission to do that.');
    }
    next();
  };
}
