// Thin re-export so route files can import rate limiters from the
// conventional "middleware" location, while the actual limiter
// definitions/settings live in one place: config/security.js.
export { globalRateLimiter, authRateLimiter } from '../config/security.js';
