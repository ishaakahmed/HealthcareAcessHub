import { Router } from 'express';
import { listCategories, createCategory } from '../controllers/category.controller.js';
import { requireAuth } from '../middleware/auth.middleware.js';
import { requireRole } from '../middleware/role.middleware.js';
import { ROLES } from '../../shared/enums.js';

const router = Router();

router.get('/', listCategories);
router.post('/', requireAuth, requireRole(ROLES.ADMIN), createCategory);

export default router;
