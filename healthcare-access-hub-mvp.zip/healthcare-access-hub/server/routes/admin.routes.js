import { Router } from 'express';
import {
  listUsers,
  updateUserRole,
  listPendingResources,
  verifyResource,
  listReports,
  resolveReport,
  getStats,
  listAuditLogs,
} from '../controllers/admin.controller.js';
import { requireAuth } from '../middleware/auth.middleware.js';
import { requireRole } from '../middleware/role.middleware.js';
import { validateObjectIdParam } from '../validators/resource.validator.js';
import { ROLES } from '../../shared/enums.js';

const router = Router();

// Every route here requires BOTH a valid session AND the admin role,
// enforced on the backend - the frontend hiding admin links is UX only.
router.use(requireAuth, requireRole(ROLES.ADMIN));

router.get('/stats', getStats);
router.get('/users', listUsers);
router.patch('/users/:id/role', validateObjectIdParam('id'), updateUserRole);
router.get('/resources/pending', listPendingResources);
router.patch('/resources/:id/verify', validateObjectIdParam('id'), verifyResource);
router.get('/reports', listReports);
router.patch('/reports/:id', validateObjectIdParam('id'), resolveReport);
router.get('/audit-logs', listAuditLogs);

export default router;
