import { Router } from 'express';
import {
  listResources,
  getResourceById,
  createResource,
  updateResource,
  deleteResource,
  saveResource,
  unsaveResource,
} from '../controllers/resource.controller.js';
import { validateResourceInput, validateObjectIdParam } from '../validators/resource.validator.js';
import { requireAuth } from '../middleware/auth.middleware.js';

const router = Router();

router.get('/', listResources);
router.get('/:id', validateObjectIdParam('id'), getResourceById);
router.post('/', requireAuth, validateResourceInput, createResource);
router.put('/:id', requireAuth, validateObjectIdParam('id'), updateResource);
router.delete('/:id', requireAuth, validateObjectIdParam('id'), deleteResource);
router.post('/:id/save', requireAuth, validateObjectIdParam('id'), saveResource);
router.delete('/:id/save', requireAuth, validateObjectIdParam('id'), unsaveResource);

export default router;
