import { Router } from 'express';
import { listArticles, getArticleById, createArticle } from '../controllers/article.controller.js';
import { requireAuth } from '../middleware/auth.middleware.js';
import { requireRole } from '../middleware/role.middleware.js';
import { ROLES } from '../../shared/enums.js';

const router = Router();

router.get('/', listArticles);
router.get('/:id', getArticleById);
router.post('/', requireAuth, requireRole(ROLES.ADMIN, ROLES.PROFESSIONAL), createArticle);

export default router;
