import { Router } from 'express';
import { getMySavedResources, getMyReports } from '../controllers/user.controller.js';
import { requireAuth } from '../middleware/auth.middleware.js';

const router = Router();

router.get('/me/saved', requireAuth, getMySavedResources);
router.get('/me/reports', requireAuth, getMyReports);

export default router;
