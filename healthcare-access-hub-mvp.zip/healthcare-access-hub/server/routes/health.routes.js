import { Router } from 'express';
import mongoose from 'mongoose';

const router = Router();

/**
 * GET /api/health
 * Simple check the frontend (and you, manually) can call to confirm:
 *  - the Express server is running
 *  - the server can see its own MongoDB connection state
 * No sensitive info is returned here - just status strings.
 */
router.get('/', (req, res) => {
  const dbStates = ['disconnected', 'connected', 'connecting', 'disconnecting'];
  const dbState = dbStates[mongoose.connection.readyState] || 'unknown';

  res.json({
    success: true,
    data: {
      server: 'ok',
      database: dbState,
      timestamp: new Date().toISOString(),
    },
  });
});

export default router;
