import { Router } from 'express';
import { listEmergencyResources, upsertEmergencyResource } from '../controllers/emergency.controller.js';
import { requireAuth } from '../middleware/auth.middleware.js';
import { requireRole } from '../middleware/role.middleware.js';
import { ROLES } from '../../shared/enums.js';

const router = Router();

router.get('/', listEmergencyResources);
router.post('/', requireAuth, requireRole(ROLES.ADMIN), upsertEmergencyResource);

export default router;
