import { Router } from 'express';
import { createReport } from '../controllers/report.controller.js';
import { validateReportInput } from '../validators/report.validator.js';
import { validateObjectIdParam } from '../validators/resource.validator.js';
import { requireAuth } from '../middleware/auth.middleware.js';

const router = Router();

// Nested under a resource id: POST /api/resources/:resourceId/reports
router.post(
  '/:resourceId/reports',
  requireAuth,
  validateObjectIdParam('resourceId'),
  validateReportInput,
  createReport
);

export default router;
