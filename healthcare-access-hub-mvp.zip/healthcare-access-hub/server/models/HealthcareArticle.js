import mongoose from 'mongoose';

const healthcareArticleSchema = new mongoose.Schema(
  {
    term: { type: String, required: true, trim: true, maxlength: 150 },
    simpleExplanation: { type: String, required: true, trim: true, maxlength: 500 },
    whyItMatters: { type: String, trim: true, maxlength: 500 },
    warningSigns: [{ type: String, trim: true }],
    category: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'HealthcareCategory',
    },
    createdBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  },
  { timestamps: true }
);

healthcareArticleSchema.index({ term: 'text', simpleExplanation: 'text' });

export default mongoose.model('HealthcareArticle', healthcareArticleSchema);
