import mongoose from 'mongoose';

const emergencyResourceSchema = new mongoose.Schema(
  {
    region: { type: String, required: true, trim: true, maxlength: 100 },
    serviceName: { type: String, required: true, trim: true, maxlength: 150 },
    phone: { type: String, required: true, trim: true, maxlength: 30 },
    notes: { type: String, trim: true, maxlength: 300 },
    updatedBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  },
  { timestamps: true }
);

export default mongoose.model('EmergencyResource', emergencyResourceSchema);
