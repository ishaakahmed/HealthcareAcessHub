import mongoose from 'mongoose';

const savedResourceSchema = new mongoose.Schema(
  {
    user: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
    resource: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'HealthcareResource',
      required: true,
    },
  },
  { timestamps: true }
);

// A user can only save the same resource once.
savedResourceSchema.index({ user: 1, resource: 1 }, { unique: true });

export default mongoose.model('SavedResource', savedResourceSchema);
