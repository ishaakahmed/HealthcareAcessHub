import mongoose from 'mongoose';

const auditLogSchema = new mongoose.Schema(
  {
    actor: { type: mongoose.Schema.Types.ObjectId, ref: 'User', default: null },
    action: { type: String, required: true, maxlength: 100 },
    targetType: { type: String, maxlength: 50 },
    targetId: { type: mongoose.Schema.Types.ObjectId, default: null },
    metadata: { type: mongoose.Schema.Types.Mixed },
    ipAddress: { type: String, maxlength: 100 },
  },
  { timestamps: true }
);

// Audit logs are append-only in practice: we never update or delete them
// from application code (no controller exposes that).
export default mongoose.model('AuditLog', auditLogSchema);
