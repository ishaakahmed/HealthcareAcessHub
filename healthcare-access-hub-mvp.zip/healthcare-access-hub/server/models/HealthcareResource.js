import mongoose from 'mongoose';
import { VERIFICATION_STATUS, COST_CATEGORY } from '../../shared/enums.js';

const healthcareResourceSchema = new mongoose.Schema(
  {
    name: { type: String, required: true, trim: true, maxlength: 150 },
    category: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'HealthcareCategory',
      required: true,
    },
    description: { type: String, required: true, trim: true, maxlength: 1000 },
    services: [{ type: String, trim: true }],
    address: { type: String, trim: true, maxlength: 300 },
    phone: { type: String, trim: true, maxlength: 30 },
    website: { type: String, trim: true, maxlength: 300 },
    isOnline: { type: Boolean, default: false },
    hours: { type: String, trim: true, maxlength: 200 },
    costCategory: {
      type: String,
      enum: Object.values(COST_CATEGORY),
      required: true,
    },
    languagesSupported: [{ type: String, trim: true }],
    verificationStatus: {
      type: String,
      enum: Object.values(VERIFICATION_STATUS),
      default: VERIFICATION_STATUS.COMMUNITY_SUBMITTED,
    },
    submittedBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
    // Demo/sample data must always be clearly labelled - never presented
    // as if it were a real, verified healthcare provider.
    isDemoData: { type: Boolean, default: true },
  },
  { timestamps: true }
);

healthcareResourceSchema.index({
  name: 'text',
  description: 'text',
  services: 'text',
});

export default mongoose.model('HealthcareResource', healthcareResourceSchema);
