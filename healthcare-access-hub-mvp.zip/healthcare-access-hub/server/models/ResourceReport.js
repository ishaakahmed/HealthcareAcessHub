import mongoose from 'mongoose';
import { REPORT_REASON } from '../../shared/enums.js';

const REPORT_STATUS = ['open', 'reviewed', 'resolved', 'dismissed'];

const resourceReportSchema = new mongoose.Schema(
  {
    resource: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'HealthcareResource',
      required: true,
    },
    reportedBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
    reason: { type: String, enum: Object.values(REPORT_REASON), required: true },
    details: { type: String, trim: true, maxlength: 500 },
    status: { type: String, enum: REPORT_STATUS, default: 'open' },
    reviewedBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User', default: null },
  },
  { timestamps: true }
);

export { REPORT_STATUS };
export default mongoose.model('ResourceReport', resourceReportSchema);
