import mongoose from 'mongoose';
import { VERIFICATION_STATUS } from '../../shared/enums.js';

const communityOrganizationSchema = new mongoose.Schema(
  {
    name: { type: String, required: true, trim: true, maxlength: 150 },
    description: { type: String, trim: true, maxlength: 500 },
    contactInfo: { type: String, trim: true, maxlength: 300 },
    verificationStatus: {
      type: String,
      enum: Object.values(VERIFICATION_STATUS),
      default: VERIFICATION_STATUS.COMMUNITY_SUBMITTED,
    },
    createdBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  },
  { timestamps: true }
);

export default mongoose.model('CommunityOrganization', communityOrganizationSchema);
