import mongoose from 'mongoose';

const categorySchema = new mongoose.Schema(
  {
    name: { type: String, required: true, trim: true, unique: true },
    slug: { type: String, required: true, trim: true, unique: true, lowercase: true },
    description: { type: String, trim: true, maxlength: 300 },
    icon: { type: String, trim: true }, // name of an icon, not raw SVG/HTML
  },
  { timestamps: true }
);

export default mongoose.model('HealthcareCategory', categorySchema);
