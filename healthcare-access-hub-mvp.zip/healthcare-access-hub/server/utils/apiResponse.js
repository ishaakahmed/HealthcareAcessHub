/**
 * Small helpers to keep every API response in the same shape:
 * { success, data } on success, { success, error } on failure.
 */
export function ok(res, data, status = 200) {
  return res.status(status).json({ success: true, data });
}

export function fail(res, status, error) {
  return res.status(status).json({ success: false, error });
}
