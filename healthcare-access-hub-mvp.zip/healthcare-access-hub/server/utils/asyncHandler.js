/**
 * Wraps an async controller so any thrown/rejected error is passed to
 * Express's error handler instead of crashing the process or hanging
 * the request. Avoids repeating try/catch in every controller.
 */
export function asyncHandler(fn) {
  return (req, res, next) => {
    Promise.resolve(fn(req, res, next)).catch(next);
  };
}
