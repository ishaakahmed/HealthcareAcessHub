import HealthcareResource from '../models/HealthcareResource.js';
import ResourceReport from '../models/ResourceReport.js';
import { ok, fail } from '../utils/apiResponse.js';
import { asyncHandler } from '../utils/asyncHandler.js';
import { logAction } from '../services/audit.service.js';
import { VERIFICATION_STATUS } from '../../shared/enums.js';

export const createReport = asyncHandler(async (req, res) => {
  const resource = await HealthcareResource.findById(req.params.resourceId);
  if (!resource) return fail(res, 404, 'Resource not found.');

  const report = await ResourceReport.create({
    resource: resource._id,
    reportedBy: req.user._id,
    reason: req.body.reason,
    details: req.body.details,
  });

  // A report is a signal something might be wrong - flip the resource to
  // "needs_review" so it's re-checked, rather than trusting it blindly.
  resource.verificationStatus = VERIFICATION_STATUS.NEEDS_REVIEW;
  await resource.save();

  await logAction({
    actor: req.user._id,
    action: 'report.submit',
    targetType: 'ResourceReport',
    targetId: report._id,
    metadata: { resourceId: resource._id, reason: report.reason },
    req,
  });

  return ok(res, { report }, 201);
});
