import SavedResource from '../models/SavedResource.js';
import ResourceReport from '../models/ResourceReport.js';
import { ok } from '../utils/apiResponse.js';
import { asyncHandler } from '../utils/asyncHandler.js';

// Powers the "User Dashboard": saved resources + reports the user has filed.
// Deliberately does not expose any other user's data (IDOR-safe: always
// scoped to req.user._id, never a client-supplied user id).
export const getMySavedResources = asyncHandler(async (req, res) => {
  const saved = await SavedResource.find({ user: req.user._id })
    .populate({
      path: 'resource',
      populate: { path: 'category', select: 'name slug' },
    })
    .sort({ createdAt: -1 });

  return ok(res, { saved });
});

export const getMyReports = asyncHandler(async (req, res) => {
  const reports = await ResourceReport.find({ reportedBy: req.user._id })
    .populate('resource', 'name')
    .sort({ createdAt: -1 });

  return ok(res, { reports });
});
