import User from '../models/User.js';
import HealthcareResource from '../models/HealthcareResource.js';
import ResourceReport from '../models/ResourceReport.js';
import AuditLog from '../models/AuditLog.js';
import { ok, fail } from '../utils/apiResponse.js';
import { asyncHandler } from '../utils/asyncHandler.js';
import { logAction } from '../services/audit.service.js';
import { VERIFICATION_STATUS, ROLES } from '../../shared/enums.js';

export const listUsers = asyncHandler(async (req, res) => {
  const users = await User.find().sort({ createdAt: -1 });
  return ok(res, { users });
});

// Admin changes a user's role. We explicitly forbid an admin
// demoting/removing their OWN admin role by accident, to avoid locking
// everyone out of admin access.
export const updateUserRole = asyncHandler(async (req, res) => {
  const { role } = req.body;
  if (!Object.values(ROLES).includes(role)) {
    return fail(res, 400, 'Invalid role.');
  }
  if (req.params.id === req.user._id.toString()) {
    return fail(res, 400, 'You cannot change your own role.');
  }

  const user = await User.findById(req.params.id);
  if (!user) return fail(res, 404, 'User not found.');

  const previousRole = user.role;
  user.role = role;
  await user.save();

  await logAction({
    actor: req.user._id,
    action: 'user.role_change',
    targetType: 'User',
    targetId: user._id,
    metadata: { from: previousRole, to: role },
    req,
  });

  return ok(res, { user });
});

export const listPendingResources = asyncHandler(async (req, res) => {
  const resources = await HealthcareResource.find({
    verificationStatus: {
      $in: [
        VERIFICATION_STATUS.COMMUNITY_SUBMITTED,
        VERIFICATION_STATUS.PENDING_VERIFICATION,
        VERIFICATION_STATUS.NEEDS_REVIEW,
      ],
    },
  })
    .populate('category', 'name')
    .sort({ createdAt: 1 });

  return ok(res, { resources });
});

export const verifyResource = asyncHandler(async (req, res) => {
  const { status, notes } = req.body;
  if (!Object.values(VERIFICATION_STATUS).includes(status)) {
    return fail(res, 400, 'Invalid verification status.');
  }

  const resource = await HealthcareResource.findById(req.params.id);
  if (!resource) return fail(res, 404, 'Resource not found.');

  resource.verificationStatus = status;
  await resource.save();

  await logAction({
    actor: req.user._id,
    action: 'resource.verify',
    targetType: 'HealthcareResource',
    targetId: resource._id,
    metadata: { status, notes },
    req,
  });

  return ok(res, { resource });
});

export const listReports = asyncHandler(async (req, res) => {
  const reports = await ResourceReport.find()
    .populate('resource', 'name')
    .populate('reportedBy', 'name email')
    .sort({ createdAt: -1 });

  return ok(res, { reports });
});

export const resolveReport = asyncHandler(async (req, res) => {
  const { status } = req.body;
  const validStatuses = ['reviewed', 'resolved', 'dismissed'];
  if (!validStatuses.includes(status)) {
    return fail(res, 400, 'Invalid report status.');
  }

  const report = await ResourceReport.findById(req.params.id);
  if (!report) return fail(res, 404, 'Report not found.');

  report.status = status;
  report.reviewedBy = req.user._id;
  await report.save();

  await logAction({
    actor: req.user._id,
    action: 'report.resolve',
    targetType: 'ResourceReport',
    targetId: report._id,
    metadata: { status },
    req,
  });

  return ok(res, { report });
});

// Basic, honest platform stats - no invented numbers.
export const getStats = asyncHandler(async (req, res) => {
  const [userCount, resourceCount, pendingCount, openReportCount] = await Promise.all([
    User.countDocuments(),
    HealthcareResource.countDocuments(),
    HealthcareResource.countDocuments({
      verificationStatus: {
        $in: [VERIFICATION_STATUS.COMMUNITY_SUBMITTED, VERIFICATION_STATUS.PENDING_VERIFICATION, VERIFICATION_STATUS.NEEDS_REVIEW],
      },
    }),
    ResourceReport.countDocuments({ status: 'open' }),
  ]);

  return ok(res, { userCount, resourceCount, pendingCount, openReportCount });
});

export const listAuditLogs = asyncHandler(async (req, res) => {
  const logs = await AuditLog.find()
    .populate('actor', 'name email role')
    .sort({ createdAt: -1 })
    .limit(200);

  return ok(res, { logs });
});
