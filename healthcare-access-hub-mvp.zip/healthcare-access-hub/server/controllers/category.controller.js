import HealthcareCategory from '../models/HealthcareCategory.js';
import { ok, fail } from '../utils/apiResponse.js';
import { asyncHandler } from '../utils/asyncHandler.js';
import { logAction } from '../services/audit.service.js';

export const listCategories = asyncHandler(async (req, res) => {
  const categories = await HealthcareCategory.find().sort({ name: 1 });
  return ok(res, { categories });
});

// Admin-only: categories are a small, curated list, not open for
// arbitrary user creation - that keeps the Navigator/Directory filters
// meaningful instead of fragmenting into duplicates.
export const createCategory = asyncHandler(async (req, res) => {
  const { name, slug, description, icon } = req.body;

  if (!name || !slug) {
    return fail(res, 400, 'Name and slug are required.');
  }

  const category = await HealthcareCategory.create({ name, slug, description, icon });

  await logAction({
    actor: req.user._id,
    action: 'category.create',
    targetType: 'HealthcareCategory',
    targetId: category._id,
    req,
  });

  return ok(res, { category }, 201);
});
