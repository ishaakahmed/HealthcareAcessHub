import EmergencyResource from '../models/EmergencyResource.js';
import { ok, fail } from '../utils/apiResponse.js';
import { asyncHandler } from '../utils/asyncHandler.js';
import { logAction } from '../services/audit.service.js';

// This is intentionally simple: admin-configurable data the frontend
// displays as-is, with no logic that tries to guess whether a situation
// is an actual emergency.
export const listEmergencyResources = asyncHandler(async (req, res) => {
  const resources = await EmergencyResource.find().sort({ region: 1 });
  return ok(res, { resources });
});

export const upsertEmergencyResource = asyncHandler(async (req, res) => {
  const { region, serviceName, phone, notes } = req.body;
  if (!region || !serviceName || !phone) {
    return fail(res, 400, 'Region, service name, and phone are required.');
  }

  const resource = await EmergencyResource.create({
    region,
    serviceName,
    phone,
    notes,
    updatedBy: req.user._id,
  });

  await logAction({
    actor: req.user._id,
    action: 'emergency.update',
    targetType: 'EmergencyResource',
    targetId: resource._id,
    req,
  });

  return ok(res, { resource }, 201);
});
