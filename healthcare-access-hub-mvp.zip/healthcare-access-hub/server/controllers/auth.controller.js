import bcrypt from 'bcryptjs';
import User from '../models/User.js';
import { ok, fail } from '../utils/apiResponse.js';
import { asyncHandler } from '../utils/asyncHandler.js';
import { signToken, setAuthCookie, clearAuthCookie } from '../utils/token.js';
import { logAction } from '../services/audit.service.js';

const MAX_FAILED_ATTEMPTS = 5;
const LOCK_DURATION_MS = 15 * 60 * 1000; // 15 minutes

export const register = asyncHandler(async (req, res) => {
  const { name, email, password } = req.body;

  const existing = await User.findOne({ email });
  if (existing) {
    // Deliberately vague - don't confirm which emails are registered.
    return fail(res, 400, 'Unable to register with these details.');
  }

  const passwordHash = await bcrypt.hash(password, 12);
  const user = await User.create({ name, email, passwordHash });

  const token = signToken(user);
  setAuthCookie(res, token);

  await logAction({ actor: user._id, action: 'user.register', targetType: 'User', targetId: user._id, req });

  return ok(res, { user }, 201);
});

export const login = asyncHandler(async (req, res) => {
  const { email, password } = req.body;

  const user = await User.findOne({ email });

  // Same generic error whether the email doesn't exist or the password is
  // wrong - this avoids leaking which emails are registered.
  const genericError = 'Invalid email or password.';

  if (!user) return fail(res, 401, genericError);

  if (user.isLocked()) {
    return fail(res, 423, 'Too many failed attempts. Please try again later.');
  }

  const validPassword = await user.comparePassword(password);

  if (!validPassword) {
    user.failedLoginAttempts += 1;
    if (user.failedLoginAttempts >= MAX_FAILED_ATTEMPTS) {
      user.lockUntil = new Date(Date.now() + LOCK_DURATION_MS);
      await logAction({ actor: user._id, action: 'user.login_locked', targetType: 'User', targetId: user._id, req });
    }
    await user.save();
    return fail(res, 401, genericError);
  }

  user.failedLoginAttempts = 0;
  user.lockUntil = null;
  await user.save();

  const token = signToken(user);
  setAuthCookie(res, token);

  await logAction({ actor: user._id, action: 'user.login', targetType: 'User', targetId: user._id, req });

  return ok(res, { user });
});

export const logout = asyncHandler(async (req, res) => {
  clearAuthCookie(res);
  return ok(res, { message: 'Logged out.' });
});

export const getCurrentUser = asyncHandler(async (req, res) => {
  return ok(res, { user: req.user });
});
