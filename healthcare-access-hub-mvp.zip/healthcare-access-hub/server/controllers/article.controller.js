import HealthcareArticle from '../models/HealthcareArticle.js';
import { ok, fail } from '../utils/apiResponse.js';
import { asyncHandler } from '../utils/asyncHandler.js';

// "Explain Healthcare Simply" - purely educational, term-focused content.
// These endpoints never accept or return anything about a specific user's
// symptoms or health - only general terminology.
export const listArticles = asyncHandler(async (req, res) => {
  const { q } = req.query;
  const filter = q ? { $text: { $search: q } } : {};
  const articles = await HealthcareArticle.find(filter).sort({ term: 1 });
  return ok(res, { articles });
});

export const getArticleById = asyncHandler(async (req, res) => {
  const article = await HealthcareArticle.findById(req.params.id);
  if (!article) return fail(res, 404, 'Article not found.');
  return ok(res, { article });
});

export const createArticle = asyncHandler(async (req, res) => {
  const { term, simpleExplanation, whyItMatters, warningSigns, category } = req.body;
  if (!term || !simpleExplanation) {
    return fail(res, 400, 'Term and a simple explanation are required.');
  }
  const article = await HealthcareArticle.create({
    term,
    simpleExplanation,
    whyItMatters,
    warningSigns,
    category,
    createdBy: req.user._id,
  });
  return ok(res, { article }, 201);
});
