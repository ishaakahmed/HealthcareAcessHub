import HealthcareResource from '../models/HealthcareResource.js';
import SavedResource from '../models/SavedResource.js';
import { ok, fail } from '../utils/apiResponse.js';
import { asyncHandler } from '../utils/asyncHandler.js';
import { logAction } from '../services/audit.service.js';
import { ROLES, VERIFICATION_STATUS } from '../../shared/enums.js';

const PAGE_SIZE = 12;

/**
 * GET /api/resources
 * Supports: ?q=text&category=<id>&cost=<cost_category>&online=true&page=1
 * This is the backbone of both the Directory and the Affordable-healthcare
 * view (which is just this endpoint with cost filters applied).
 */
export const listResources = asyncHandler(async (req, res) => {
  const { q, category, cost, online, page = 1 } = req.query;

  const filter = {};
  if (category) filter.category = category;
  if (cost) filter.costCategory = cost;
  if (online === 'true') filter.isOnline = true;
  if (q) filter.$text = { $search: q };

  // Publicly, only show resources that have at least been community
  // submitted and reviewed once - "needs_review" items are hidden from
  // the public directory until an admin looks at them.
  filter.verificationStatus = { $ne: VERIFICATION_STATUS.NEEDS_REVIEW };

  const pageNum = Math.max(parseInt(page, 10) || 1, 1);
  const skip = (pageNum - 1) * PAGE_SIZE;

  const [resources, total] = await Promise.all([
    HealthcareResource.find(filter)
      .populate('category', 'name slug')
      .sort({ createdAt: -1 })
      .skip(skip)
      .limit(PAGE_SIZE),
    HealthcareResource.countDocuments(filter),
  ]);

  return ok(res, {
    resources,
    pagination: { page: pageNum, pageSize: PAGE_SIZE, total, totalPages: Math.ceil(total / PAGE_SIZE) },
  });
});

export const getResourceById = asyncHandler(async (req, res) => {
  const resource = await HealthcareResource.findById(req.params.id).populate('category', 'name slug');
  if (!resource) return fail(res, 404, 'Resource not found.');
  return ok(res, { resource });
});

/**
 * Any logged-in user can submit a resource; it always starts as
 * "community_submitted" (or "pending_verification" for professionals)
 * regardless of what the client sends - status is server-controlled.
 */
export const createResource = asyncHandler(async (req, res) => {
  const startingStatus =
    req.user.role === ROLES.PROFESSIONAL
      ? VERIFICATION_STATUS.PENDING_VERIFICATION
      : VERIFICATION_STATUS.COMMUNITY_SUBMITTED;

  const resource = await HealthcareResource.create({
    ...req.body,
    submittedBy: req.user._id,
    verificationStatus: startingStatus,
    isDemoData: false, // real user-submitted data, not seed/demo data
  });

  await logAction({
    actor: req.user._id,
    action: 'resource.submit',
    targetType: 'HealthcareResource',
    targetId: resource._id,
    req,
  });

  return ok(res, { resource }, 201);
});

/**
 * Owner or admin can edit. Verification status can ONLY be changed via
 * the admin verification endpoint, never through this general update -
 * that keeps the trust pipeline meaningful.
 */
export const updateResource = asyncHandler(async (req, res) => {
  const resource = await HealthcareResource.findById(req.params.id);
  if (!resource) return fail(res, 404, 'Resource not found.');

  const isOwner = resource.submittedBy?.toString() === req.user._id.toString();
  if (!isOwner && req.user.role !== ROLES.ADMIN) {
    return fail(res, 403, 'You do not have permission to edit this resource.');
  }

  const { verificationStatus, submittedBy, isDemoData, ...safeUpdates } = req.body;
  Object.assign(resource, safeUpdates);
  await resource.save();

  return ok(res, { resource });
});

export const deleteResource = asyncHandler(async (req, res) => {
  const resource = await HealthcareResource.findById(req.params.id);
  if (!resource) return fail(res, 404, 'Resource not found.');

  const isOwner = resource.submittedBy?.toString() === req.user._id.toString();
  if (!isOwner && req.user.role !== ROLES.ADMIN) {
    return fail(res, 403, 'You do not have permission to delete this resource.');
  }

  await resource.deleteOne();

  await logAction({
    actor: req.user._id,
    action: 'resource.delete',
    targetType: 'HealthcareResource',
    targetId: resource._id,
    req,
  });

  return ok(res, { message: 'Resource deleted.' });
});

export const saveResource = asyncHandler(async (req, res) => {
  const resource = await HealthcareResource.findById(req.params.id);
  if (!resource) return fail(res, 404, 'Resource not found.');

  await SavedResource.findOneAndUpdate(
    { user: req.user._id, resource: resource._id },
    { user: req.user._id, resource: resource._id },
    { upsert: true }
  );

  return ok(res, { message: 'Resource saved.' });
});

export const unsaveResource = asyncHandler(async (req, res) => {
  await SavedResource.deleteOne({ user: req.user._id, resource: req.params.id });
  return ok(res, { message: 'Resource removed from saved list.' });
});
