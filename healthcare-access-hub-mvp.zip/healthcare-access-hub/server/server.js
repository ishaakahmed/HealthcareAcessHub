import 'dotenv/config';
import express from 'express';
import cookieParser from 'cookie-parser';
import { connectDB } from './config/db.js';
import { applySecurityMiddleware } from './middleware/security.middleware.js';
import { errorHandler, notFoundHandler } from './middleware/errorHandler.js';

import healthRoutes from './routes/health.routes.js';
import authRoutes from './routes/auth.routes.js';
import categoryRoutes from './routes/categories.routes.js';
import resourceRoutes from './routes/resources.routes.js';
import reportRoutes from './routes/reports.routes.js';
import articleRoutes from './routes/articles.routes.js';
import emergencyRoutes from './routes/emergency.routes.js';
import adminRoutes from './routes/admin.routes.js';
import userRoutes from './routes/users.routes.js';

const app = express();
const PORT = process.env.PORT || 5000;

// 1. Security middleware first (headers, CORS, sanitization, rate limiting)
applySecurityMiddleware(app);

// 2. Body/cookie parsing, with an explicit body size limit.
app.use(express.json({ limit: '100kb' }));
app.use(express.urlencoded({ extended: true, limit: '100kb' }));
app.use(cookieParser());

// 3. Routes
app.use('/api/health', healthRoutes);
app.use('/api/auth', authRoutes);
app.use('/api/categories', categoryRoutes);
app.use('/api/resources', resourceRoutes);
app.use('/api/resources', reportRoutes); // adds /:resourceId/reports under the same base
app.use('/api/articles', articleRoutes);
app.use('/api/emergency', emergencyRoutes);
app.use('/api/admin', adminRoutes);
app.use('/api/users', userRoutes);

// 4. 404 handler for unmatched routes
app.use(notFoundHandler);

// 5. Central error handler - must be last
app.use(errorHandler);

// 6. Connect to MongoDB, then start listening.
connectDB().then(() => {
  app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
});
