import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

// Proxies "/api" calls to the Express server during development, so the
// browser sees same-origin requests and we avoid dev-time CORS friction.
// In production, the real API URL is used instead (see src/services/api.js).
export default defineConfig({
  plugins: [react()],
  server: {
    port: 5173,
    proxy: {
      '/api': {
        target: 'http://localhost:5000',
        changeOrigin: true,
      },
    },
    // shared/enums.js lives one level above /client (in the project root),
    // so it can be imported from both frontend and backend. This tells
    // Vite's dev server it's allowed to serve files from up there.
    fs: {
      allow: ['..'],
    },
  },
});
