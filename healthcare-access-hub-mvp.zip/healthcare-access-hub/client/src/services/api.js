// Centralized place for talking to the backend API.
// In dev, Vite proxies "/api" to the Express server (see vite.config.js).
const BASE_URL = import.meta.env.VITE_API_BASE_URL || '/api';

async function request(path, options = {}) {
  const response = await fetch(`${BASE_URL}${path}`, {
    credentials: 'include', // send the httpOnly auth cookie
    headers: { 'Content-Type': 'application/json', ...options.headers },
    ...options,
  });

  const body = await response.json().catch(() => null);

  if (!response.ok || !body?.success) {
    throw new Error(body?.error || 'Something went wrong. Please try again.');
  }
  return body.data;
}

export const api = {
  get: (path) => request(path, { method: 'GET' }),
  post: (path, data) => request(path, { method: 'POST', body: JSON.stringify(data) }),
  put: (path, data) => request(path, { method: 'PUT', body: JSON.stringify(data) }),
  patch: (path, data) => request(path, { method: 'PATCH', body: JSON.stringify(data) }),
  delete: (path) => request(path, { method: 'DELETE' }),
};

export const checkHealth = () => api.get('/health');

// Auth
export const registerUser = (data) => api.post('/auth/register', data);
export const loginUser = (data) => api.post('/auth/login', data);
export const logoutUser = () => api.post('/auth/logout');
export const fetchCurrentUser = () => api.get('/auth/me');

// Categories
export const fetchCategories = () => api.get('/categories');

// Resources
export const fetchResources = (params = {}) => {
  const query = new URLSearchParams(
    Object.entries(params).filter(([, v]) => v !== undefined && v !== '')
  ).toString();
  return api.get(`/resources${query ? `?${query}` : ''}`);
};
export const fetchResourceById = (id) => api.get(`/resources/${id}`);
export const submitResource = (data) => api.post('/resources', data);
export const saveResourceForUser = (id) => api.post(`/resources/${id}/save`);
export const unsaveResourceForUser = (id) => api.delete(`/resources/${id}/save`);
export const reportResource = (id, data) => api.post(`/resources/${id}/reports`, data);

// Articles ("Explain Healthcare Simply")
export const fetchArticles = (q) => api.get(`/articles${q ? `?q=${encodeURIComponent(q)}` : ''}`);

// Emergency
export const fetchEmergencyResources = () => api.get('/emergency');

// User dashboard
export const fetchMySavedResources = () => api.get('/users/me/saved');
export const fetchMyReports = () => api.get('/users/me/reports');

// Admin
export const fetchAdminStats = () => api.get('/admin/stats');
export const fetchAllUsers = () => api.get('/admin/users');
export const updateUserRole = (id, role) => api.patch(`/admin/users/${id}/role`, { role });
export const fetchPendingResources = () => api.get('/admin/resources/pending');
export const verifyResourceStatus = (id, status, notes) =>
  api.patch(`/admin/resources/${id}/verify`, { status, notes });
export const fetchAllReports = () => api.get('/admin/reports');
export const resolveReportStatus = (id, status) => api.patch(`/admin/reports/${id}`, { status });
export const fetchAuditLogs = () => api.get('/admin/audit-logs');
