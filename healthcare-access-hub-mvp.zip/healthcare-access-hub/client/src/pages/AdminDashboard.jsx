import { useEffect, useState } from 'react';
import {
  fetchAdminStats, fetchAllUsers, updateUserRole,
  fetchPendingResources, verifyResourceStatus,
  fetchAllReports, resolveReportStatus, fetchAuditLogs,
} from '../services/api.js';
import LoadingState from '../components/LoadingState.jsx';
import EmptyState from '../components/EmptyState.jsx';
import Badge from '../components/Badge.jsx';
import { ROLES, VERIFICATION_STATUS } from '../../../shared/enums.js';

const TABS = ['Overview', 'Pending Resources', 'Reports', 'Users', 'Audit Log'];

export default function AdminDashboard() {
  const [tab, setTab] = useState('Overview');

  return (
    <div className="max-w-5xl mx-auto px-4 py-10">
      <h1 className="text-2xl font-bold text-slate-800">Admin Dashboard</h1>

      <div className="mt-6 flex flex-wrap gap-2 border-b border-slate-200">
        {TABS.map((t) => (
          <button
            key={t}
            onClick={() => setTab(t)}
            className={`px-4 py-2 text-sm font-medium border-b-2 -mb-px ${
              tab === t ? 'border-teal-600 text-teal-700' : 'border-transparent text-slate-500'
            }`}
          >
            {t}
          </button>
        ))}
      </div>

      <div className="mt-6">
        {tab === 'Overview' && <OverviewTab />}
        {tab === 'Pending Resources' && <PendingResourcesTab />}
        {tab === 'Reports' && <ReportsTab />}
        {tab === 'Users' && <UsersTab />}
        {tab === 'Audit Log' && <AuditLogTab />}
      </div>
    </div>
  );
}

function OverviewTab() {
  const [stats, setStats] = useState(null);
  useEffect(() => { fetchAdminStats().then((d) => setStats(d)); }, []);
  if (!stats) return <LoadingState />;
  const cards = [
    ['Total Users', stats.userCount],
    ['Total Resources', stats.resourceCount],
    ['Pending Review', stats.pendingCount],
    ['Open Reports', stats.openReportCount],
  ];
  return (
    <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
      {cards.map(([label, value]) => (
        <div key={label} className="rounded-xl border border-slate-200 bg-white p-5 text-center">
          <p className="text-2xl font-bold text-teal-700">{value}</p>
          <p className="text-sm text-slate-500 mt-1">{label}</p>
        </div>
      ))}
    </div>
  );
}

function PendingResourcesTab() {
  const [resources, setResources] = useState(null);

  function load() { fetchPendingResources().then((d) => setResources(d.resources)); }
  useEffect(load, []);

  async function handleVerify(id, status) {
    await verifyResourceStatus(id, status);
    load();
  }

  if (!resources) return <LoadingState />;
  if (resources.length === 0) return <EmptyState title="Nothing pending review" />;

  return (
    <div className="space-y-3">
      {resources.map((r) => (
        <div key={r._id} className="rounded-xl border border-slate-200 bg-white p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="font-medium text-slate-800">{r.name}</p>
              <p className="text-xs text-slate-500">{r.category?.name}</p>
            </div>
            <Badge status={r.verificationStatus} />
          </div>
          <p className="text-sm text-slate-600 mt-2">{r.description}</p>
          <div className="mt-3 flex gap-2">
            <button onClick={() => handleVerify(r._id, VERIFICATION_STATUS.VERIFIED)} className="px-3 py-1.5 rounded-lg bg-green-600 text-white text-xs font-medium">Verify</button>
            <button onClick={() => handleVerify(r._id, VERIFICATION_STATUS.NEEDS_REVIEW)} className="px-3 py-1.5 rounded-lg bg-amber-500 text-white text-xs font-medium">Needs Review</button>
          </div>
        </div>
      ))}
    </div>
  );
}

function ReportsTab() {
  const [reports, setReports] = useState(null);
  function load() { fetchAllReports().then((d) => setReports(d.reports)); }
  useEffect(load, []);

  async function handleResolve(id, status) {
    await resolveReportStatus(id, status);
    load();
  }

  if (!reports) return <LoadingState />;
  if (reports.length === 0) return <EmptyState title="No reports filed" />;

  return (
    <div className="space-y-3">
      {reports.map((r) => (
        <div key={r._id} className="rounded-xl border border-slate-200 bg-white p-4 flex items-center justify-between">
          <div>
            <p className="font-medium text-slate-800">{r.resource?.name || 'Resource removed'}</p>
            <p className="text-xs text-slate-500">{r.reason.replace(/_/g, ' ')} — by {r.reportedBy?.name}</p>
            {r.details && <p className="text-sm text-slate-600 mt-1">{r.details}</p>}
          </div>
          <div className="flex gap-2">
            {r.status === 'open' && (
              <>
                <button onClick={() => handleResolve(r._id, 'resolved')} className="px-3 py-1.5 rounded-lg bg-green-600 text-white text-xs font-medium">Resolve</button>
                <button onClick={() => handleResolve(r._id, 'dismissed')} className="px-3 py-1.5 rounded-lg bg-slate-400 text-white text-xs font-medium">Dismiss</button>
              </>
            )}
            {r.status !== 'open' && <span className="text-xs uppercase text-slate-500">{r.status}</span>}
          </div>
        </div>
      ))}
    </div>
  );
}

function UsersTab() {
  const [users, setUsers] = useState(null);
  function load() { fetchAllUsers().then((d) => setUsers(d.users)); }
  useEffect(load, []);

  async function handleRoleChange(id, role) {
    await updateUserRole(id, role);
    load();
  }

  if (!users) return <LoadingState />;

  return (
    <div className="space-y-2">
      {users.map((u) => (
        <div key={u._id} className="rounded-lg border border-slate-200 bg-white p-3 flex items-center justify-between">
          <div>
            <p className="font-medium text-slate-800">{u.name}</p>
            <p className="text-xs text-slate-500">{u.email}</p>
          </div>
          <select
            defaultValue={u.role}
            onChange={(e) => handleRoleChange(u._id, e.target.value)}
            className="rounded-lg border border-slate-300 px-2 py-1 text-sm"
          >
            {Object.values(ROLES).map((r) => <option key={r} value={r}>{r}</option>)}
          </select>
        </div>
      ))}
    </div>
  );
}

function AuditLogTab() {
  const [logs, setLogs] = useState(null);
  useEffect(() => { fetchAuditLogs().then((d) => setLogs(d.logs)); }, []);
  if (!logs) return <LoadingState />;
  if (logs.length === 0) return <EmptyState title="No audit log entries yet" />;

  return (
    <div className="overflow-x-auto">
      <table className="w-full text-sm">
        <thead>
          <tr className="text-left text-slate-500 border-b border-slate-200">
            <th className="py-2 pr-4">When</th>
            <th className="py-2 pr-4">Actor</th>
            <th className="py-2 pr-4">Action</th>
            <th className="py-2 pr-4">Target</th>
          </tr>
        </thead>
        <tbody>
          {logs.map((l) => (
            <tr key={l._id} className="border-b border-slate-100">
              <td className="py-2 pr-4 text-slate-500">{new Date(l.createdAt).toLocaleString()}</td>
              <td className="py-2 pr-4">{l.actor?.name || 'System'}</td>
              <td className="py-2 pr-4">{l.action}</td>
              <td className="py-2 pr-4 text-slate-500">{l.targetType}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
