export default function About() {
  return (
    <div className="max-w-3xl mx-auto px-4 py-12">
      <h1 className="text-2xl font-bold text-slate-800">About / How It Works</h1>
      <div className="mt-6 space-y-4 text-slate-700 leading-relaxed">
        <p>
          Healthcare Access Hub is a community navigation and information tool. It helps
          people understand what kind of healthcare help they might need, and find resources
          such as clinics, telehealth services, NGOs, and government programs.
        </p>
        <p className="font-semibold text-slate-800">What this platform IS:</p>
        <ul className="list-disc pl-6 space-y-1">
          <li>A directory of healthcare-related resources and services</li>
          <li>A guide toward the right general category of help</li>
          <li>A source of plain-language educational information</li>
        </ul>
        <p className="font-semibold text-slate-800">What this platform is NOT:</p>
        <ul className="list-disc pl-6 space-y-1">
          <li>It does not diagnose any medical condition</li>
          <li>It is not a replacement for a qualified healthcare professional</li>
          <li>It does not provide prescriptions or personalized treatment plans</li>
        </ul>
        <p>
          Resources in the directory carry a verification status so you can see how much
          they've been checked. Data currently shown is clearly labelled demo/sample data
          until verified real sources are added.
        </p>
      </div>
    </div>
  );
}
