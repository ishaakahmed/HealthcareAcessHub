import { Link } from 'react-router-dom';

export default function Landing() {
  return (
    <div>
      <section className="max-w-4xl mx-auto px-4 py-16 text-center">
        <h1 className="text-3xl md:text-4xl font-bold text-slate-800">
          Find the right healthcare support, understand your options, and access trusted community resources.
        </h1>
        <p className="mt-4 text-slate-600 max-w-2xl mx-auto">
          This platform helps you find and understand healthcare services near you or online.
          It does not diagnose conditions or replace advice from a qualified healthcare professional.
        </p>
        <div className="mt-8 flex flex-wrap gap-3 justify-center">
          <Link to="/navigator" className="px-6 py-3 rounded-lg bg-teal-600 text-white font-medium hover:bg-teal-700">
            What kind of help do you need?
          </Link>
          <Link to="/directory" className="px-6 py-3 rounded-lg border border-slate-300 text-slate-700 font-medium hover:bg-slate-50">
            Browse the Directory
          </Link>
        </div>
      </section>

      <section className="max-w-5xl mx-auto px-4 pb-16 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {[
          { to: '/affordable', title: 'Affordable Healthcare', desc: 'Filter for free, low-cost, and government/NGO-supported services.' },
          { to: '/explain-simply', title: 'Explain Healthcare Simply', desc: 'Plain-language explanations of common medical terms.' },
          { to: '/emergency', title: 'Emergency Help', desc: 'Quick access to emergency guidance and contacts.' },
          { to: '/scam-awareness', title: 'Scam Awareness', desc: 'Learn to recognize fake doctors, pharmacies, and health scams.' },
          { to: '/privacy', title: 'Privacy & Security', desc: 'What we collect, why, and how your data is protected.' },
          { to: '/about', title: 'How It Works', desc: 'Understand what this platform is - and isn\u2019t.' },
        ].map((c) => (
          <Link key={c.to} to={c.to} className="rounded-xl border border-slate-200 bg-white p-5 hover:shadow-md transition-shadow">
            <h3 className="font-semibold text-slate-800">{c.title}</h3>
            <p className="text-sm text-slate-600 mt-1">{c.desc}</p>
          </Link>
        ))}
      </section>
    </div>
  );
}
