import { useEffect, useState } from 'react';
import { fetchArticles } from '../services/api.js';
import LoadingState from '../components/LoadingState.jsx';
import ErrorState from '../components/ErrorState.jsx';
import EmptyState from '../components/EmptyState.jsx';

export default function ExplainSimply() {
  const [query, setQuery] = useState('');
  const [articles, setArticles] = useState(null);
  const [error, setError] = useState(null);
  const [loading, setLoading] = useState(true);

  function load(q) {
    setLoading(true);
    fetchArticles(q)
      .then((data) => setArticles(data.articles))
      .catch((err) => setError(err.message))
      .finally(() => setLoading(false));
  }

  useEffect(() => { load(''); }, []);

  return (
    <div className="max-w-3xl mx-auto px-4 py-12">
      <h1 className="text-2xl font-bold text-slate-800">Explain Healthcare Simply</h1>
      <p className="mt-2 text-slate-600">
        Search a medical term to see it explained in plain language. This is general education,
        not advice about your personal situation.
      </p>

      <form
        className="mt-6 flex gap-2"
        onSubmit={(e) => { e.preventDefault(); load(query); }}
      >
        <input
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="e.g. hypertension"
          className="flex-1 rounded-lg border border-slate-300 px-4 py-2"
        />
        <button className="px-4 py-2 rounded-lg bg-teal-600 text-white font-medium">Search</button>
      </form>

      <div className="mt-6 space-y-4">
        {loading && <LoadingState />}
        {error && <ErrorState message={error} />}
        {!loading && articles?.length === 0 && (
          <EmptyState title="No terms found" description="Try a different search, or check back later - more terms are added over time." />
        )}
        {articles?.map((a) => (
          <div key={a._id} className="rounded-xl border border-slate-200 bg-white p-5">
            <h3 className="font-semibold text-slate-800">{a.term}</h3>
            <p className="text-sm text-slate-700 mt-2">{a.simpleExplanation}</p>
            {a.whyItMatters && (
              <p className="text-sm text-slate-600 mt-2"><span className="font-medium">Why it matters: </span>{a.whyItMatters}</p>
            )}
            {a.warningSigns?.length > 0 && (
              <div className="mt-2 text-sm text-amber-700">
                <span className="font-medium">Contact a healthcare professional if you notice: </span>
                {a.warningSigns.join(', ')}
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}
