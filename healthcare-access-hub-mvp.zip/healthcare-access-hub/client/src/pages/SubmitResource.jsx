import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { fetchCategories, submitResource } from '../services/api.js';
import { COST_CATEGORY } from '../../../shared/enums.js';

export default function SubmitResource() {
  const navigate = useNavigate();
  const [categories, setCategories] = useState([]);
  const [error, setError] = useState(null);
  const [submitting, setSubmitting] = useState(false);
  const [form, setForm] = useState({
    name: '', category: '', description: '', address: '', phone: '',
    website: '', isOnline: false, hours: '', costCategory: '',
  });

  useEffect(() => {
    fetchCategories().then((d) => setCategories(d.categories)).catch(() => {});
  }, []);

  async function handleSubmit(e) {
    e.preventDefault();
    setError(null);
    setSubmitting(true);
    try {
      const resource = await submitResource(form);
      navigate(`/directory/${resource.resource._id}`);
    } catch (err) {
      setError(err.message);
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <div className="max-w-xl mx-auto px-4 py-10">
      <h1 className="text-2xl font-bold text-slate-800">Submit a Healthcare Resource</h1>
      <p className="text-sm text-slate-500 mt-1">
        Submitted resources start as "Community Submitted" and are reviewed by an admin before
        being fully trusted. Please don't submit real providers you haven't confirmed are accurate.
      </p>

      <form onSubmit={handleSubmit} className="mt-6 space-y-4">
        <input required placeholder="Resource name" value={form.name}
          onChange={(e) => setForm({ ...form, name: e.target.value })}
          className="w-full rounded-lg border border-slate-300 px-4 py-2" />

        <select required value={form.category} onChange={(e) => setForm({ ...form, category: e.target.value })}
          className="w-full rounded-lg border border-slate-300 px-4 py-2">
          <option value="">Select a category...</option>
          {categories.map((c) => <option key={c._id} value={c._id}>{c.name}</option>)}
        </select>

        <textarea required minLength={10} placeholder="Description (what this resource offers)" value={form.description}
          onChange={(e) => setForm({ ...form, description: e.target.value })}
          className="w-full rounded-lg border border-slate-300 px-4 py-2" />

        <input placeholder="Address" value={form.address}
          onChange={(e) => setForm({ ...form, address: e.target.value })}
          className="w-full rounded-lg border border-slate-300 px-4 py-2" />

        <input placeholder="Phone" value={form.phone}
          onChange={(e) => setForm({ ...form, phone: e.target.value })}
          className="w-full rounded-lg border border-slate-300 px-4 py-2" />

        <input placeholder="Website (https://...)" value={form.website}
          onChange={(e) => setForm({ ...form, website: e.target.value })}
          className="w-full rounded-lg border border-slate-300 px-4 py-2" />

        <input placeholder="Hours (e.g. Mon-Fri 9am-5pm)" value={form.hours}
          onChange={(e) => setForm({ ...form, hours: e.target.value })}
          className="w-full rounded-lg border border-slate-300 px-4 py-2" />

        <select required value={form.costCategory} onChange={(e) => setForm({ ...form, costCategory: e.target.value })}
          className="w-full rounded-lg border border-slate-300 px-4 py-2">
          <option value="">Select cost category...</option>
          {Object.values(COST_CATEGORY).map((c) => <option key={c} value={c}>{c.replace(/_/g, ' ')}</option>)}
        </select>

        <label className="flex items-center gap-2 text-sm text-slate-600">
          <input type="checkbox" checked={form.isOnline}
            onChange={(e) => setForm({ ...form, isOnline: e.target.checked })} />
          Available online
        </label>

        {error && <p className="text-sm text-red-600">{error}</p>}
        <button disabled={submitting} className="w-full py-2 rounded-lg bg-teal-600 text-white font-medium disabled:opacity-60">
          {submitting ? 'Submitting...' : 'Submit for Review'}
        </button>
      </form>
    </div>
  );
}
