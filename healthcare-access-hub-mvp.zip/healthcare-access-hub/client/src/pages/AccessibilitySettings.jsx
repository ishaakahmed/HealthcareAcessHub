import { useAccessibility } from '../context/AccessibilityContext.jsx';

const OPTIONS = [
  { key: 'largeText', label: 'Large text mode', desc: 'Increases text size across the whole site.' },
  { key: 'highContrast', label: 'High contrast mode', desc: 'Increases color contrast for readability.' },
  { key: 'reducedMotion', label: 'Reduced motion', desc: 'Minimizes animations and transitions.' },
];

export default function AccessibilitySettings() {
  const { prefs, toggle } = useAccessibility();

  return (
    <div className="max-w-lg mx-auto px-4 py-12">
      <h1 className="text-2xl font-bold text-slate-800">Accessibility Settings</h1>
      <p className="mt-2 text-slate-600">These preferences are saved on this device and apply across the whole site.</p>

      <div className="mt-6 space-y-4">
        {OPTIONS.map((opt) => (
          <label key={opt.key} className="flex items-start gap-3 rounded-xl border border-slate-200 bg-white p-4 cursor-pointer">
            <input
              type="checkbox"
              checked={prefs[opt.key]}
              onChange={() => toggle(opt.key)}
              className="mt-1 h-5 w-5"
            />
            <span>
              <span className="block font-medium text-slate-800">{opt.label}</span>
              <span className="block text-sm text-slate-500">{opt.desc}</span>
            </span>
          </label>
        ))}
      </div>
    </div>
  );
}
