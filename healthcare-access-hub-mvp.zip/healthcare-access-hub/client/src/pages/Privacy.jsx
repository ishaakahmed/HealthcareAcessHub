export default function Privacy() {
  return (
    <div className="max-w-3xl mx-auto px-4 py-12">
      <h1 className="text-2xl font-bold text-slate-800">Privacy & Security Center</h1>
      <div className="mt-6 space-y-6 text-slate-700 leading-relaxed">
        <div>
          <h2 className="font-semibold text-slate-800">What we collect</h2>
          <p>Your name, email, and password (securely hashed) for your account. Resources you save,
          and reports you submit. That's it - we follow the principle of collecting the minimum
          information required.</p>
        </div>
        <div>
          <h2 className="font-semibold text-slate-800">What we never ask you for</h2>
          <p>We never ask for your medical history, diagnoses, insurance numbers, or payment card
          details through this platform.</p>
        </div>
        <div>
          <h2 className="font-semibold text-slate-800">How your account is protected</h2>
          <p>Passwords are hashed (never stored in plain text). Login attempts are rate-limited
          and temporarily locked after repeated failures. Your session is stored in a secure,
          HTTP-only cookie that scripts on the page cannot read.</p>
        </div>
        <div>
          <h2 className="font-semibold text-slate-800">Reporting suspicious activity</h2>
          <p>If something about a resource looks wrong or suspicious, use "Report incorrect
          information" on that resource's page. See also our <a href="/scam-awareness" className="text-teal-700 underline">Scam Awareness</a> guide.</p>
        </div>
      </div>
    </div>
  );
}
