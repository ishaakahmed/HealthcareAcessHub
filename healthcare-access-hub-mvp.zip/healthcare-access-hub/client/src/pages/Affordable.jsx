import { useEffect, useState } from 'react';
import { fetchResources } from '../services/api.js';
import ResourceCard from '../components/ResourceCard.jsx';
import LoadingState from '../components/LoadingState.jsx';
import ErrorState from '../components/ErrorState.jsx';
import EmptyState from '../components/EmptyState.jsx';
import { COST_CATEGORY } from '../../../shared/enums.js';

const FILTERS = [
  { value: '', label: 'All' },
  { value: COST_CATEGORY.FREE, label: 'Free' },
  { value: COST_CATEGORY.LOW_COST, label: 'Low-cost' },
  { value: COST_CATEGORY.GOVERNMENT_SUPPORTED, label: 'Government-supported' },
  { value: COST_CATEGORY.NGO_SUPPORTED, label: 'NGO/community-supported' },
  { value: COST_CATEGORY.INSURANCE_SUPPORTED, label: 'Insurance-supported' },
  { value: COST_CATEGORY.ONLINE_CONSULTATION, label: 'Online consultation' },
];

export default function Affordable() {
  const [cost, setCost] = useState('');
  const [result, setResult] = useState(null);
  const [error, setError] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    setLoading(true);
    fetchResources({ cost })
      .then(setResult)
      .catch((err) => setError(err.message))
      .finally(() => setLoading(false));
  }, [cost]);

  return (
    <div className="max-w-6xl mx-auto px-4 py-10">
      <h1 className="text-2xl font-bold text-slate-800">Looking for affordable or free healthcare?</h1>
      <div className="mt-6 flex flex-wrap gap-2">
        {FILTERS.map((f) => (
          <button
            key={f.value}
            onClick={() => setCost(f.value)}
            className={`px-4 py-2 rounded-full text-sm font-medium border ${
              cost === f.value ? 'bg-teal-600 text-white border-teal-600' : 'border-slate-300 text-slate-600'
            }`}
          >
            {f.label}
          </button>
        ))}
      </div>

      <div className="mt-8">
        {loading && <LoadingState />}
        {error && <ErrorState message={error} />}
        {!loading && result?.resources.length === 0 && (
          <EmptyState title="No resources found for this filter" />
        )}
        {!loading && result?.resources.length > 0 && (
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {result.resources.map((r) => <ResourceCard key={r._id} resource={r} />)}
          </div>
        )}
      </div>
    </div>
  );
}
