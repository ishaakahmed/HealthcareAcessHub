const SCAMS = [
  { title: 'Fake doctors', desc: 'Profiles claiming medical credentials with no way to verify them. Check verification badges and licensing boards before trusting advice.' },
  { title: 'Fake pharmacies', desc: 'Websites selling medication without a prescription or at suspiciously low prices. Legitimate pharmacies require valid prescriptions for regulated drugs.' },
  { title: 'Fake medical websites', desc: 'Sites mimicking real hospitals or government health portals. Check the domain carefully and look for official verification.' },
  { title: 'Fake health claims', desc: '"Miracle cure" claims for serious conditions. Be skeptical of anything promising guaranteed results with no medical basis.' },
  { title: 'Fraudulent payment requests', desc: 'Urgent requests to pay via gift cards, crypto, or wire transfer for "treatment" or "emergency" fees. Legitimate providers do not do this.' },
  { title: 'Fake emergency messages', desc: 'Messages claiming a family member is in the hospital and needs money urgently. Verify independently before sending anything.' },
  { title: 'Fake medicine advertisements', desc: 'Ads for unapproved supplements or drugs claiming to treat serious illnesses. Consult a professional before buying.' },
];

export default function ScamAwareness() {
  return (
    <div className="max-w-3xl mx-auto px-4 py-12">
      <h1 className="text-2xl font-bold text-slate-800">Healthcare Scam Awareness</h1>
      <p className="mt-3 text-slate-600">
        Online healthcare access also comes with risks. Here's what to watch for.
      </p>
      <div className="mt-6 space-y-4">
        {SCAMS.map((s) => (
          <div key={s.title} className="rounded-xl border border-slate-200 bg-white p-5">
            <h3 className="font-semibold text-slate-800">{s.title}</h3>
            <p className="text-sm text-slate-600 mt-1">{s.desc}</p>
          </div>
        ))}
      </div>
      <p className="mt-6 text-sm text-slate-500">
        If you spot something like this on this platform, please use "Report incorrect information"
        on the resource, choosing "Suspicious/scam resource" as the reason.
      </p>
    </div>
  );
}
