import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { fetchCategories } from '../services/api.js';
import { NAVIGATOR_OPTIONS } from '../data/navigatorOptions.js';
import LoadingState from '../components/LoadingState.jsx';

/**
 * The Healthcare Service Navigator: a guided "what do you need?" flow.
 * It only ever routes the user to a RESOURCE CATEGORY or a dedicated page
 * (Emergency / Affordable) - it never asks about symptoms and never
 * produces anything resembling a diagnosis.
 */
export default function Navigator() {
  const [categories, setCategories] = useState(null);
  const navigate = useNavigate();

  useEffect(() => {
    fetchCategories().then((data) => setCategories(data.categories)).catch(() => setCategories([]));
  }, []);

  function handleSelect(option) {
    if (option.route) {
      navigate(option.route);
      return;
    }
    const match = categories?.find((c) => c.slug === option.categorySlug);
    navigate(match ? `/directory?category=${match._id}` : '/directory');
  }

  if (!categories) return <LoadingState label="Loading the Navigator..." />;

  return (
    <div className="max-w-3xl mx-auto px-4 py-12">
      <h1 className="text-2xl font-bold text-slate-800">What kind of help do you need?</h1>
      <p className="mt-2 text-slate-600">
        Choose the option closest to what you're looking for. We'll guide you to the right kind of
        resource - we won't try to diagnose anything.
      </p>

      <div className="mt-8 grid sm:grid-cols-2 gap-3">
        {NAVIGATOR_OPTIONS.map((option) => (
          <button
            key={option.id}
            onClick={() => handleSelect(option)}
            className="text-left rounded-xl border border-slate-200 bg-white p-5 hover:border-teal-400 hover:shadow-md transition-all font-medium text-slate-800"
          >
            {option.label}
          </button>
        ))}
      </div>
    </div>
  );
}
