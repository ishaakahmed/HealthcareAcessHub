import { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import {
  fetchResourceById,
  saveResourceForUser,
  unsaveResourceForUser,
  reportResource,
} from '../services/api.js';
import { useAuth } from '../context/AuthContext.jsx';
import Badge from '../components/Badge.jsx';
import LoadingState from '../components/LoadingState.jsx';
import ErrorState from '../components/ErrorState.jsx';
import { REPORT_REASON } from '../../../shared/enums.js';

const REASON_LABELS = {
  wrong_phone: 'Wrong phone number',
  closed_service: 'Closed service',
  incorrect_address: 'Incorrect address',
  incorrect_medical_info: 'Incorrect medical information',
  duplicate_resource: 'Duplicate resource',
  suspicious_scam: 'Suspicious/scam resource',
  other: 'Other',
};

export default function ResourceDetails() {
  const { id } = useParams();
  const { user } = useAuth();
  const [resource, setResource] = useState(null);
  const [error, setError] = useState(null);
  const [saveMsg, setSaveMsg] = useState('');
  const [showReport, setShowReport] = useState(false);
  const [reportReason, setReportReason] = useState('');
  const [reportDetails, setReportDetails] = useState('');
  const [reportMsg, setReportMsg] = useState('');

  useEffect(() => {
    fetchResourceById(id).then((data) => setResource(data.resource)).catch((err) => setError(err.message));
  }, [id]);

  async function handleSave() {
    try {
      await saveResourceForUser(id);
      setSaveMsg('Saved to your dashboard.');
    } catch (err) {
      setSaveMsg(err.message);
    }
  }

  async function handleReportSubmit(e) {
    e.preventDefault();
    try {
      await reportResource(id, { reason: reportReason, details: reportDetails });
      setReportMsg('Thank you - your report has been submitted for review.');
      setShowReport(false);
    } catch (err) {
      setReportMsg(err.message);
    }
  }

  if (error) return <ErrorState message={error} />;
  if (!resource) return <LoadingState />;

  return (
    <div className="max-w-2xl mx-auto px-4 py-10">
      <div className="flex items-start justify-between gap-3">
        <h1 className="text-2xl font-bold text-slate-800">{resource.name}</h1>
        <Badge status={resource.verificationStatus} />
      </div>
      {resource.category?.name && <p className="text-teal-700 text-sm mt-1">{resource.category.name}</p>}
      {resource.isDemoData && <p className="text-xs italic text-slate-400 mt-1">Demo/sample data — not a real, verified provider.</p>}

      <p className="mt-4 text-slate-700">{resource.description}</p>

      <div className="mt-6 space-y-2 text-sm text-slate-700">
        {resource.address && <p><span className="font-medium">Address:</span> {resource.address}</p>}
        {resource.phone && <p><span className="font-medium">Phone:</span> {resource.phone}</p>}
        {resource.website && <p><span className="font-medium">Website:</span> <a href={resource.website} target="_blank" rel="noreferrer" className="text-teal-700 underline">{resource.website}</a></p>}
        {resource.hours && <p><span className="font-medium">Hours:</span> {resource.hours}</p>}
        <p><span className="font-medium">Cost:</span> {resource.costCategory?.replace(/_/g, ' ')}</p>
        {resource.languagesSupported?.length > 0 && <p><span className="font-medium">Languages:</span> {resource.languagesSupported.join(', ')}</p>}
        {resource.isOnline && <p className="text-teal-700">Available online</p>}
      </div>

      {user && (
        <div className="mt-8 flex flex-wrap gap-3">
          <button onClick={handleSave} className="px-4 py-2 rounded-lg border border-teal-600 text-teal-700 font-medium hover:bg-teal-50">
            Save resource
          </button>
          <button onClick={() => setShowReport((s) => !s)} className="px-4 py-2 rounded-lg border border-slate-300 text-slate-600 font-medium hover:bg-slate-50">
            Report incorrect information
          </button>
        </div>
      )}
      {saveMsg && <p className="text-sm text-slate-500 mt-2">{saveMsg}</p>}
      {reportMsg && <p className="text-sm text-slate-500 mt-2">{reportMsg}</p>}

      {showReport && (
        <form onSubmit={handleReportSubmit} className="mt-4 p-4 rounded-xl border border-slate-200 bg-slate-50 space-y-3">
          <select required value={reportReason} onChange={(e) => setReportReason(e.target.value)} className="w-full rounded-lg border border-slate-300 px-3 py-2">
            <option value="">Select a reason...</option>
            {Object.values(REPORT_REASON).map((r) => <option key={r} value={r}>{REASON_LABELS[r]}</option>)}
          </select>
          <textarea
            value={reportDetails}
            onChange={(e) => setReportDetails(e.target.value)}
            placeholder="Optional details (max 500 characters)"
            maxLength={500}
            className="w-full rounded-lg border border-slate-300 px-3 py-2"
          />
          <button className="px-4 py-2 rounded-lg bg-teal-600 text-white font-medium">Submit report</button>
        </form>
      )}

      {!user && (
        <p className="mt-6 text-sm text-slate-500">Log in to save this resource or report an issue.</p>
      )}
    </div>
  );
}
