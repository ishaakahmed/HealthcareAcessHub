import { useEffect, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { fetchResources, fetchCategories } from '../services/api.js';
import ResourceCard from '../components/ResourceCard.jsx';
import LoadingState from '../components/LoadingState.jsx';
import ErrorState from '../components/ErrorState.jsx';
import EmptyState from '../components/EmptyState.jsx';
import { COST_CATEGORY } from '../../../shared/enums.js';

export default function Directory() {
  const [searchParams, setSearchParams] = useSearchParams();
  const [categories, setCategories] = useState([]);
  const [result, setResult] = useState(null);
  const [error, setError] = useState(null);
  const [loading, setLoading] = useState(true);

  const q = searchParams.get('q') || '';
  const category = searchParams.get('category') || '';
  const cost = searchParams.get('cost') || '';
  const page = searchParams.get('page') || '1';

  useEffect(() => {
    fetchCategories().then((data) => setCategories(data.categories)).catch(() => {});
  }, []);

  useEffect(() => {
    setLoading(true);
    setError(null);
    fetchResources({ q, category, cost, page })
      .then(setResult)
      .catch((err) => setError(err.message))
      .finally(() => setLoading(false));
  }, [q, category, cost, page]);

  function updateParam(key, value) {
    const next = new URLSearchParams(searchParams);
    if (value) next.set(key, value); else next.delete(key);
    next.set('page', '1');
    setSearchParams(next);
  }

  return (
    <div className="max-w-6xl mx-auto px-4 py-10">
      <h1 className="text-2xl font-bold text-slate-800">Resource Directory</h1>

      <div className="mt-6 flex flex-wrap gap-3">
        <input
          defaultValue={q}
          onKeyDown={(e) => e.key === 'Enter' && updateParam('q', e.target.value)}
          onBlur={(e) => updateParam('q', e.target.value)}
          placeholder="Search e.g. 'affordable dentist'"
          className="flex-1 min-w-[200px] rounded-lg border border-slate-300 px-4 py-2"
        />
        <select value={category} onChange={(e) => updateParam('category', e.target.value)} className="rounded-lg border border-slate-300 px-3 py-2">
          <option value="">All categories</option>
          {categories.map((c) => (
            <option key={c._id} value={c._id}>{c.name}</option>
          ))}
        </select>
        <select value={cost} onChange={(e) => updateParam('cost', e.target.value)} className="rounded-lg border border-slate-300 px-3 py-2">
          <option value="">Any cost</option>
          {Object.values(COST_CATEGORY).map((c) => (
            <option key={c} value={c}>{c.replace(/_/g, ' ')}</option>
          ))}
        </select>
      </div>

      <div className="mt-8">
        {loading && <LoadingState />}
        {error && <ErrorState message={error} />}
        {!loading && result?.resources.length === 0 && (
          <EmptyState title="No resources match your filters" description="Try clearing a filter or searching a broader term." />
        )}
        {!loading && result?.resources.length > 0 && (
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {result.resources.map((r) => <ResourceCard key={r._id} resource={r} />)}
          </div>
        )}

        {result?.pagination.totalPages > 1 && (
          <div className="flex justify-center gap-2 mt-8">
            {Array.from({ length: result.pagination.totalPages }, (_, i) => i + 1).map((p) => (
              <button
                key={p}
                onClick={() => setSearchParams((prev) => { const n = new URLSearchParams(prev); n.set('page', p); return n; })}
                className={`w-9 h-9 rounded-lg border text-sm ${String(p) === page ? 'bg-teal-600 text-white border-teal-600' : 'border-slate-300 text-slate-600'}`}
              >
                {p}
              </button>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
