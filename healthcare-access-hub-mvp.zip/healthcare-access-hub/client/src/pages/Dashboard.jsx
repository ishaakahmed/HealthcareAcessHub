import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { fetchMySavedResources, fetchMyReports } from '../services/api.js';
import { useAuth } from '../context/AuthContext.jsx';
import LoadingState from '../components/LoadingState.jsx';
import EmptyState from '../components/EmptyState.jsx';
import Badge from '../components/Badge.jsx';

export default function Dashboard() {
  const { user } = useAuth();
  const [saved, setSaved] = useState(null);
  const [reports, setReports] = useState(null);

  useEffect(() => {
    fetchMySavedResources().then((d) => setSaved(d.saved)).catch(() => setSaved([]));
    fetchMyReports().then((d) => setReports(d.reports)).catch(() => setReports([]));
  }, []);

  return (
    <div className="max-w-4xl mx-auto px-4 py-10">
      <h1 className="text-2xl font-bold text-slate-800">Welcome, {user.name}</h1>
      <p className="text-sm text-slate-500 mt-1">{user.email} — role: {user.role}</p>

      <div className="mt-4 flex gap-3">
        <Link to="/submit-resource" className="px-4 py-2 rounded-lg bg-teal-600 text-white text-sm font-medium">Submit a Resource</Link>
        <Link to="/accessibility" className="px-4 py-2 rounded-lg border border-slate-300 text-slate-600 text-sm font-medium">Accessibility Settings</Link>
      </div>

      <section className="mt-10">
        <h2 className="font-semibold text-slate-800">Saved Resources</h2>
        {!saved && <LoadingState />}
        {saved?.length === 0 && <EmptyState title="No saved resources yet" description="Resources you save from the Directory will appear here." />}
        <div className="mt-3 space-y-2">
          {saved?.map((s) => s.resource && (
            <Link key={s._id} to={`/directory/${s.resource._id}`} className="block rounded-lg border border-slate-200 bg-white p-3 hover:shadow-sm">
              <span className="font-medium text-slate-800">{s.resource.name}</span>
              <span className="text-xs text-slate-500 ml-2">{s.resource.category?.name}</span>
            </Link>
          ))}
        </div>
      </section>

      <section className="mt-10">
        <h2 className="font-semibold text-slate-800">Your Reports</h2>
        {!reports && <LoadingState />}
        {reports?.length === 0 && <EmptyState title="You haven't submitted any reports" />}
        <div className="mt-3 space-y-2">
          {reports?.map((r) => (
            <div key={r._id} className="rounded-lg border border-slate-200 bg-white p-3 flex items-center justify-between">
              <div>
                <p className="font-medium text-slate-800">{r.resource?.name || 'Resource removed'}</p>
                <p className="text-xs text-slate-500">{r.reason.replace(/_/g, ' ')}</p>
              </div>
              <span className="text-xs uppercase tracking-wide text-slate-500">{r.status}</span>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}
