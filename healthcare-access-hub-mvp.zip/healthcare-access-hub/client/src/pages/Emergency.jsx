import { useEffect, useState } from 'react';
import { fetchEmergencyResources } from '../services/api.js';
import LoadingState from '../components/LoadingState.jsx';
import ErrorState from '../components/ErrorState.jsx';
import EmptyState from '../components/EmptyState.jsx';

export default function Emergency() {
  const [resources, setResources] = useState(null);
  const [error, setError] = useState(null);

  useEffect(() => {
    fetchEmergencyResources()
      .then((data) => setResources(data.resources))
      .catch((err) => setError(err.message));
  }, []);

  return (
    <div className="max-w-3xl mx-auto px-4 py-12">
      <div className="rounded-xl bg-red-50 border border-red-200 p-6 text-center">
        <h1 className="text-xl font-bold text-red-700">Emergency Help</h1>
        <p className="mt-2 text-red-800 font-medium">
          If you believe this is an emergency, contact your local emergency service
          or go to the nearest emergency department right away.
        </p>
        <p className="mt-2 text-sm text-red-700">
          This page does not assess whether your situation is an emergency - when in doubt, seek
          immediate in-person or emergency-line help.
        </p>
      </div>

      <h2 className="mt-8 font-semibold text-slate-800">Configured Emergency Contacts</h2>
      <div className="mt-3 space-y-3">
        {!resources && !error && <LoadingState />}
        {error && <ErrorState message={error} />}
        {resources && resources.length === 0 && (
          <EmptyState title="No emergency contacts configured yet" description="An administrator has not added any yet." />
        )}
        {resources?.map((r) => (
          <div key={r._id} className="rounded-lg border border-slate-200 bg-white p-4">
            <p className="font-medium text-slate-800">{r.serviceName} — {r.region}</p>
            <p className="text-teal-700 font-semibold">{r.phone}</p>
            {r.notes && <p className="text-sm text-slate-500 mt-1">{r.notes}</p>}
          </div>
        ))}
      </div>
    </div>
  );
}
