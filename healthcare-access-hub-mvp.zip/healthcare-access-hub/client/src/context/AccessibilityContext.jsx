import { createContext, useContext, useEffect, useState } from 'react';

const AccessibilityContext = createContext(null);
const STORAGE_KEY = 'accessibility-preferences';

const DEFAULTS = { largeText: false, highContrast: false, reducedMotion: false };

function loadPreferences() {
  try {
    const saved = localStorage.getItem(STORAGE_KEY);
    return saved ? { ...DEFAULTS, ...JSON.parse(saved) } : DEFAULTS;
  } catch {
    return DEFAULTS;
  }
}

/**
 * Accessibility is treated as an app-wide, persistent setting rather than a
 * per-page afterthought: one toggle affects every page via CSS classes on
 * <html>, and the choice is remembered across visits.
 */
export function AccessibilityProvider({ children }) {
  const [prefs, setPrefs] = useState(loadPreferences);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(prefs));
    const root = document.documentElement;
    root.classList.toggle('a11y-large-text', prefs.largeText);
    root.classList.toggle('a11y-high-contrast', prefs.highContrast);
    root.classList.toggle('a11y-reduced-motion', prefs.reducedMotion);
  }, [prefs]);

  function toggle(key) {
    setPrefs((p) => ({ ...p, [key]: !p[key] }));
  }

  return (
    <AccessibilityContext.Provider value={{ prefs, toggle }}>
      {children}
    </AccessibilityContext.Provider>
  );
}

export function useAccessibility() {
  const ctx = useContext(AccessibilityContext);
  if (!ctx) throw new Error('useAccessibility must be used within an AccessibilityProvider');
  return ctx;
}
