import { Routes, Route } from 'react-router-dom';
import Navbar from './components/Navbar.jsx';
import Footer from './components/Footer.jsx';
import EmergencyBanner from './components/EmergencyBanner.jsx';
import ProtectedRoute from './components/ProtectedRoute.jsx';

import Landing from './pages/Landing.jsx';
import Navigator from './pages/Navigator.jsx';
import Directory from './pages/Directory.jsx';
import ResourceDetails from './pages/ResourceDetails.jsx';
import Affordable from './pages/Affordable.jsx';
import ExplainSimply from './pages/ExplainSimply.jsx';
import Emergency from './pages/Emergency.jsx';
import ScamAwareness from './pages/ScamAwareness.jsx';
import Privacy from './pages/Privacy.jsx';
import About from './pages/About.jsx';
import Login from './pages/Login.jsx';
import Register from './pages/Register.jsx';
import Dashboard from './pages/Dashboard.jsx';
import AdminDashboard from './pages/AdminDashboard.jsx';
import SubmitResource from './pages/SubmitResource.jsx';
import AccessibilitySettings from './pages/AccessibilitySettings.jsx';

function NotFound() {
  return (
    <div className="max-w-md mx-auto px-4 py-24 text-center">
      <h1 className="text-xl font-semibold text-slate-800">Page not found</h1>
      <p className="text-slate-500 mt-2">The page you're looking for doesn't exist.</p>
    </div>
  );
}

function App() {
  return (
    <div className="min-h-screen flex flex-col bg-slate-50">
      <EmergencyBanner />
      <Navbar />

      <main className="flex-1">
        <Routes>
          <Route path="/" element={<Landing />} />
          <Route path="/navigator" element={<Navigator />} />
          <Route path="/directory" element={<Directory />} />
          <Route path="/directory/:id" element={<ResourceDetails />} />
          <Route path="/affordable" element={<Affordable />} />
          <Route path="/explain-simply" element={<ExplainSimply />} />
          <Route path="/emergency" element={<Emergency />} />
          <Route path="/scam-awareness" element={<ScamAwareness />} />
          <Route path="/privacy" element={<Privacy />} />
          <Route path="/about" element={<About />} />
          <Route path="/login" element={<Login />} />
          <Route path="/register" element={<Register />} />

          <Route path="/dashboard" element={<ProtectedRoute><Dashboard /></ProtectedRoute>} />
          <Route path="/submit-resource" element={<ProtectedRoute><SubmitResource /></ProtectedRoute>} />
          <Route path="/accessibility" element={<AccessibilitySettings />} />
          <Route
            path="/admin"
            element={<ProtectedRoute requireRole="admin"><AdminDashboard /></ProtectedRoute>}
          />

          <Route path="*" element={<NotFound />} />
        </Routes>
      </main>

      <Footer />
    </div>
  );
}

export default App;
