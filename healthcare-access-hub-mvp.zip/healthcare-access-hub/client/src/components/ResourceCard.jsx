import { Link } from 'react-router-dom';
import Badge from './Badge.jsx';

export default function ResourceCard({ resource }) {
  return (
    <Link
      to={`/directory/${resource._id}`}
      className="block rounded-xl border border-slate-200 bg-white p-5 shadow-sm hover:shadow-md transition-shadow"
    >
      <div className="flex items-start justify-between gap-2">
        <h3 className="font-semibold text-slate-800">{resource.name}</h3>
        <Badge status={resource.verificationStatus} />
      </div>
      {resource.category?.name && (
        <p className="text-xs text-teal-700 mt-1">{resource.category.name}</p>
      )}
      <p className="text-sm text-slate-600 mt-2 line-clamp-2">{resource.description}</p>
      <div className="flex flex-wrap gap-2 mt-3 text-xs text-slate-500">
        {resource.isOnline && <span className="bg-slate-100 px-2 py-1 rounded-full">Online</span>}
        <span className="bg-slate-100 px-2 py-1 rounded-full">{resource.costCategory?.replace(/_/g, ' ')}</span>
      </div>
      {resource.isDemoData && (
        <p className="text-[11px] text-slate-400 mt-2 italic">Demo/sample data</p>
      )}
    </Link>
  );
}
