import { Link, NavLink } from 'react-router-dom';
import { useAuth } from '../context/AuthContext.jsx';
import { useLanguage } from '../i18n/LanguageContext.jsx';

const linkClass = ({ isActive }) =>
  `px-3 py-2 rounded-md text-sm font-medium ${
    isActive ? 'bg-teal-100 text-teal-800' : 'text-slate-600 hover:bg-slate-100'
  }`;

export default function Navbar() {
  const { user, logout } = useAuth();
  const { t } = useLanguage();

  return (
    <header className="border-b border-slate-200 bg-white sticky top-0 z-40">
      <nav className="max-w-6xl mx-auto px-4 flex items-center justify-between h-16" aria-label="Main navigation">
        <Link to="/" className="font-semibold text-teal-700 text-lg">
          {t('appName')}
        </Link>

        <div className="hidden md:flex items-center gap-1">
          <NavLink to="/navigator" className={linkClass}>{t('nav.navigator')}</NavLink>
          <NavLink to="/directory" className={linkClass}>{t('nav.directory')}</NavLink>
          <NavLink to="/affordable" className={linkClass}>{t('nav.affordable')}</NavLink>
          <NavLink to="/explain-simply" className={linkClass}>{t('nav.explainSimply')}</NavLink>
          <NavLink to="/emergency" className="px-3 py-2 rounded-md text-sm font-semibold text-red-700 hover:bg-red-50">
            {t('nav.emergency')}
          </NavLink>
        </div>

        <div className="flex items-center gap-2">
          {user ? (
            <>
              <NavLink to="/dashboard" className={linkClass}>{t('nav.dashboard')}</NavLink>
              {user.role === 'admin' && (
                <NavLink to="/admin" className={linkClass}>{t('nav.admin')}</NavLink>
              )}
              <button
                onClick={logout}
                className="px-3 py-2 rounded-md text-sm font-medium text-slate-600 hover:bg-slate-100"
              >
                {t('nav.logout')}
              </button>
            </>
          ) : (
            <>
              <NavLink to="/login" className={linkClass}>{t('nav.login')}</NavLink>
              <Link
                to="/register"
                className="px-3 py-2 rounded-md text-sm font-medium bg-teal-600 text-white hover:bg-teal-700"
              >
                {t('nav.register')}
              </Link>
            </>
          )}
        </div>
      </nav>
    </header>
  );
}
