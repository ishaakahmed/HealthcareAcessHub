const STYLES = {
  verified: 'bg-green-100 text-green-800',
  pending_verification: 'bg-amber-100 text-amber-800',
  community_submitted: 'bg-blue-100 text-blue-800',
  needs_review: 'bg-red-100 text-red-800',
};

const LABELS = {
  verified: 'Verified',
  pending_verification: 'Pending Verification',
  community_submitted: 'Community Submitted',
  needs_review: 'Needs Review',
};

export default function Badge({ status }) {
  return (
    <span className={`inline-block text-xs font-medium px-2 py-1 rounded-full ${STYLES[status] || 'bg-slate-100 text-slate-700'}`}>
      {LABELS[status] || status}
    </span>
  );
}
