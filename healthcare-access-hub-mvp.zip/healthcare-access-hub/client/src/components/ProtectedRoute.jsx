import { Navigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext.jsx';
import LoadingState from './LoadingState.jsx';

/**
 * Client-side route gating is a UX convenience only - the real
 * authorization check always happens on the backend (requireAuth /
 * requireRole middleware). This component just avoids flashing protected
 * content before redirecting an unauthenticated/unauthorized user.
 */
export default function ProtectedRoute({ children, requireRole }) {
  const { user, loading } = useAuth();

  if (loading) return <LoadingState />;
  if (!user) return <Navigate to="/login" replace />;
  if (requireRole && user.role !== requireRole) return <Navigate to="/dashboard" replace />;

  return children;
}
