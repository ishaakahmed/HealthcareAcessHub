import { Link } from 'react-router-dom';

/**
 * Shown persistently so emergency guidance is always one tap away.
 * Deliberately never tries to assess whether the user's situation IS an
 * emergency - it only ever points to real emergency services.
 */
export default function EmergencyBanner() {
  return (
    <div className="bg-red-600 text-white text-center text-sm py-2 px-4">
      If you believe this is an emergency, contact your local emergency service or go to the nearest emergency department.{' '}
      <Link to="/emergency" className="underline font-semibold">More emergency info</Link>
    </div>
  );
}
