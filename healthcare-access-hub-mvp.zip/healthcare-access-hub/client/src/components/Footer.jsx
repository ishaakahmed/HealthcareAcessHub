import { Link } from 'react-router-dom';

export default function Footer() {
  return (
    <footer className="border-t border-slate-200 mt-16 py-8 text-sm text-slate-500">
      <div className="max-w-6xl mx-auto px-4 flex flex-wrap gap-x-6 gap-y-2 justify-between">
        <p>Healthcare Access Hub — a community navigation project, not a medical provider.</p>
        <div className="flex gap-4">
          <Link to="/about" className="hover:text-slate-700">About</Link>
          <Link to="/accessibility" className="hover:text-slate-700">Accessibility</Link>
          <Link to="/privacy" className="hover:text-slate-700">Privacy</Link>
          <Link to="/scam-awareness" className="hover:text-slate-700">Scam Awareness</Link>
        </div>
      </div>
    </footer>
  );
}
