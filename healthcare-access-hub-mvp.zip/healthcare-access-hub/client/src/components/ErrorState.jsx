export default function ErrorState({ message = 'Something went wrong. Please try again.' }) {
  return (
    <div className="text-center py-16">
      <p className="text-red-600 font-medium">{message}</p>
    </div>
  );
}
