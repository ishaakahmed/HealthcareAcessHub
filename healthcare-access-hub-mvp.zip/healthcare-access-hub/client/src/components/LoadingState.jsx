export default function LoadingState({ label = 'Loading...' }) {
  return (
    <div className="flex items-center justify-center py-16 text-slate-500" role="status" aria-live="polite">
      <span className="animate-spin h-5 w-5 border-2 border-teal-600 border-t-transparent rounded-full mr-3" />
      {label}
    </div>
  );
}
