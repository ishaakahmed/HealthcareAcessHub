export default function EmptyState({ title = 'Nothing here yet', description }) {
  return (
    <div className="text-center py-16 text-slate-500">
      <p className="font-medium text-slate-700">{title}</p>
      {description && <p className="text-sm mt-1">{description}</p>}
    </div>
  );
}
