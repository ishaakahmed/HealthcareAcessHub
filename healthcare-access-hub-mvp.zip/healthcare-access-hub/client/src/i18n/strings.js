// Multilingual-ready structure: all user-facing UI strings live in ONE
// place, keyed by language code. Adding a new language later means adding
// a new top-level key here (e.g. "hi" for Hindi) - no component code needs
// to change. Only English is populated for the MVP, per the "don't
// over-engineer" instruction - the structure is what matters right now.
export const STRINGS = {
  en: {
    appName: 'Healthcare Access Hub',
    tagline: 'Find the right healthcare support, understand your options, and access trusted community resources.',
    nav: {
      home: 'Home',
      navigator: 'Find Help',
      directory: 'Directory',
      affordable: 'Affordable Care',
      explainSimply: 'Explain Simply',
      emergency: 'Emergency',
      scamAwareness: 'Scam Awareness',
      privacy: 'Privacy',
      login: 'Log In',
      register: 'Sign Up',
      dashboard: 'Dashboard',
      admin: 'Admin',
      logout: 'Log Out',
    },
    demoDataNotice: 'Demo/sample data — not a real healthcare provider.',
  },
};
