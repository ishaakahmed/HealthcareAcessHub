import { createContext, useContext, useState } from 'react';
import { STRINGS } from './strings.js';

const LanguageContext = createContext(null);

export function LanguageProvider({ children }) {
  const [language, setLanguage] = useState('en');

  function t(path) {
    const value = path
      .split('.')
      .reduce((obj, key) => (obj ? obj[key] : undefined), STRINGS[language] || STRINGS.en);
    return value ?? path;
  }

  return (
    <LanguageContext.Provider value={{ language, setLanguage, t }}>
      {children}
    </LanguageContext.Provider>
  );
}

export function useLanguage() {
  const ctx = useContext(LanguageContext);
  if (!ctx) throw new Error('useLanguage must be used within a LanguageProvider');
  return ctx;
}
