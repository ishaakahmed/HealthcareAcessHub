// Maps a plain-language "what do you need?" option to where the Navigator
// should send the user. This is UI routing logic only - it never attempts
// to diagnose anything, it just points to a resource CATEGORY or a
// dedicated page (like Emergency or Affordable Care).
export const NAVIGATOR_OPTIONS = [
  { id: 'doctor', label: 'I need a doctor', categorySlug: 'general-physician' },
  { id: 'mental-health', label: 'I need mental-health support', categorySlug: 'mental-health' },
  { id: 'medicine-info', label: 'I need medicine information', categorySlug: 'medicine-information' },
  { id: 'affordable', label: 'I need an affordable healthcare service', route: '/affordable' },
  { id: 'emergency', label: 'I need emergency help', route: '/emergency' },
  { id: 'diagnostic', label: 'I need a diagnostic/lab service', categorySlug: 'diagnostic-lab' },
  { id: 'maternal-child', label: 'I need maternal/child healthcare', categorySlug: 'maternal-child' },
  { id: 'elderly-care', label: 'I need elderly care', categorySlug: 'elderly-care' },
  { id: 'vaccination', label: 'I need vaccination information', categorySlug: 'vaccination' },
  { id: 'government', label: 'I need government/community healthcare assistance', categorySlug: 'government-community' },
];
