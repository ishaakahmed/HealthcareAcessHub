/**
 * Shared constants/enums.
 *
 * Only values that genuinely need to stay identical on both the client
 * and the server live here, so they can never drift out of sync.
 * This file has no dependencies and works in both a Node (CommonJS-via-ESM)
 * and a Vite/React (ES module) environment because we use plain ESM exports.
 */

export const ROLES = Object.freeze({
  MEMBER: 'member',
  NGO: 'ngo',
  PROFESSIONAL: 'professional',
  ADMIN: 'admin',
});

export const VERIFICATION_STATUS = Object.freeze({
  VERIFIED: 'verified',
  PENDING_VERIFICATION: 'pending_verification',
  COMMUNITY_SUBMITTED: 'community_submitted',
  NEEDS_REVIEW: 'needs_review',
});

export const COST_CATEGORY = Object.freeze({
  FREE: 'free',
  LOW_COST: 'low_cost',
  GOVERNMENT_SUPPORTED: 'government_supported',
  NGO_SUPPORTED: 'ngo_supported',
  INSURANCE_SUPPORTED: 'insurance_supported',
  ONLINE_CONSULTATION: 'online_consultation',
});

export const REPORT_REASON = Object.freeze({
  WRONG_PHONE: 'wrong_phone',
  CLOSED_SERVICE: 'closed_service',
  INCORRECT_ADDRESS: 'incorrect_address',
  INCORRECT_MEDICAL_INFO: 'incorrect_medical_info',
  DUPLICATE_RESOURCE: 'duplicate_resource',
  SUSPICIOUS_SCAM: 'suspicious_scam',
  OTHER: 'other',
});
