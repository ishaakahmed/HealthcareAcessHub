# Healthcare Access Hub

A community-focused healthcare **navigation and information** platform. It helps
people — especially those with limited digital literacy or limited healthcare
access — find and understand healthcare services. **It does not diagnose
conditions, provide prescriptions, or replace advice from a qualified
healthcare professional.**

## Features

- **Healthcare Service Navigator** — guided "what do you need?" flow that routes
  to a resource category (never a diagnosis).
- **Resource Directory** — searchable, filterable (category, cost, online) list
  of healthcare-related resources with a verification-status badge.
- **Affordable Healthcare view** — quick filtering for free/low-cost/government/
  NGO/insurance-supported/online-consultation resources.
- **Explain Healthcare Simply** — plain-language glossary of medical terms
  (meaning, why it matters, warning signs) — general education only.
- **Emergency Help** — always-visible banner + a dedicated page with
  admin-configurable emergency contacts. Never attempts to assess whether a
  situation is an emergency.
- **Resource submission & verification pipeline** — community members and
  professionals can submit resources; admins verify/reject them.
- **Report incorrect information** — flag a resource (wrong phone, closed,
  scam, etc.); reported resources are automatically flagged "needs review."
- **Scam Awareness** and **Privacy & Security Center** — static educational pages.
- **User Dashboard** — saved resources, submitted reports.
- **Admin Dashboard** — stats, pending-resource verification, report review,
  user role management, audit log viewer.
- **Accessibility mode** — large text, high contrast, reduced motion; persisted
  per-device, available to everyone (no login required).
- **Multilingual-ready architecture** — all UI strings centralized in
  `client/src/i18n/strings.js`; only English is populated for the MVP, but
  adding a language means adding a key, not touching component code.

All directory/article/emergency data shipped with this repo is **clearly
labelled demo/sample data** (`isDemoData: true`, `[DEMO]` name prefixes) — no
real providers, credentials, or phone numbers are used.

## Technology Stack

- **Frontend:** React 18 + Vite, React Router, Tailwind CSS
- **Backend:** Node.js + Express (ES modules)
- **Database:** MongoDB + Mongoose
- **Auth:** JWT stored in an httpOnly, secure, sameSite cookie (not localStorage)
- **Security:** helmet, cors, express-rate-limit, express-mongo-sanitize, bcryptjs

## Folder Structure

```
healthcare-access-hub/
├── client/                 React + Vite + Tailwind frontend
│   └── src/
│       ├── pages/          One file per route
│       ├── components/     Navbar, ResourceCard, ProtectedRoute, states, etc.
│       ├── context/        AuthContext, AccessibilityContext
│       ├── i18n/           Multilingual string dictionary
│       ├── data/           Navigator need→category mapping
│       └── services/api.js Centralized fetch wrapper
├── server/                 Node + Express backend
│   ├── config/             db.js (Mongo connection), security.js (CORS/rate-limit config)
│   ├── models/             Mongoose schemas
│   ├── controllers/        Route handlers
│   ├── routes/             Express routers
│   ├── middleware/         auth, role (RBAC), security, error handler, audit
│   ├── validators/         Request validation (auth, resource, report)
│   ├── services/           audit.service.js (writes to AuditLog)
│   ├── utils/               asyncHandler, JWT helpers, response shape
│   └── seed.js             Demo data + demo accounts
└── shared/enums.js         Roles, verification statuses, cost categories,
                             report reasons — imported by BOTH client and server
```

## Environment Variables

**`server/.env`** (copy from `server/.env.example`):
```
PORT=5000
NODE_ENV=development
MONGO_URI=mongodb://127.0.0.1:27017/healthcare_access_hub
CLIENT_ORIGIN=http://localhost:5173
JWT_SECRET=<generate with: openssl rand -base64 48>
```

**`client/.env`** (optional — only needed if not using the Vite dev proxy):
```
VITE_API_BASE_URL=/api
```

## Setup & Running Locally

Requires Node.js and a running MongoDB (local `mongod` or MongoDB Atlas).

```bash
# 1. Backend
cd server
cp .env.example .env      # edit MONGO_URI and JWT_SECRET
npm install
npm run seed                # populates demo categories/resources/articles + demo accounts
npm run dev                 # http://localhost:5000

# 2. Frontend (second terminal)
cd client
npm install
npm run dev                 # http://localhost:5173
```

## Demo Accounts (created by `npm run seed`)

| Role   | Email              | Password        |
|--------|--------------------|-----------------|
| Admin  | admin@demo.local   | DemoAdmin123!   |
| Member | member@demo.local  | DemoMember123!  |

Change or remove these before any real deployment.

## Database Setup

No manual schema creation needed — Mongoose creates collections on first write.
Run `npm run seed` after connecting to a fresh database to populate demo
categories, resources, articles, an emergency-contact placeholder, and the two
demo accounts above. Seeding is idempotent for the demo accounts (won't
duplicate them) but re-running it replaces demo-flagged resources/categories.

## Security Considerations

- Passwords hashed with bcrypt (cost factor 12); never stored or returned in
  plain text (`User.toJSON` strips the hash).
- JWT stored in an httpOnly, secure (in production), sameSite cookie — not
  accessible to client-side JavaScript, mitigating XSS-based token theft.
- Login/register are rate-limited (10 attempts / 15 min); accounts lock for
  15 minutes after 5 consecutive failed logins.
- All state-changing routes enforce authorization **server-side** via
  `requireAuth` / `requireRole` middleware — the frontend hiding a button is
  UX only, never the real access control.
- IDOR protection: resource/report ownership is checked against the
  authenticated user's ID, never a client-supplied ID; dashboard queries are
  always scoped to `req.user._id`.
- `express-mongo-sanitize` strips `$`/`.` keys from input to prevent
  MongoDB operator injection; `validator`-based validators check shape and
  type before controllers run.
- `helmet()` sets standard protective headers; CORS is restricted to the
  configured `CLIENT_ORIGIN`, not `*`.
- Global + auth-specific rate limiting via `express-rate-limit`.
- Centralized error handler never returns stack traces to the client — full
  details are logged server-side only.
- **Audit logging**: resource verification, report resolution, role changes,
  resource submission/deletion, and login/register/lockout events are all
  recorded in the `AuditLog` collection (viewable in Admin → Audit Log).

## Healthcare Safety Measures

- No feature anywhere claims to diagnose a condition or suggests personalized
  treatment — the Navigator only ever resolves to a resource *category*.
- "Explain Healthcare Simply" articles describe *terms*, never the reader's
  personal situation, and include "when to contact a professional" guidance.
- The Emergency page and banner never attempt to assess whether a situation
  is an emergency — they always defer to local emergency services.
- All seed/demo resources are explicitly flagged (`isDemoData`, `[DEMO]`
  prefix) and shown with a visible "Demo/sample data" note in the UI.
- Resource verification statuses (`verified`, `pending_verification`,
  `community_submitted`, `needs_review`) are shown on every resource card so
  users can gauge trust level themselves.

## Accessibility Features

- Large text, high contrast, and reduced-motion modes — toggle at `/accessibility`,
  no login required, persisted per device, applied site-wide via CSS classes
  on `<html>`.
- Visible focus outlines on all interactive elements (keyboard navigation).
- Semantic HTML (`<nav>`, `<main>`, `<footer>`, labelled form inputs) and
  `aria-live` on loading states.
- Plain-language content throughout; minimal medical jargon.

## Known Issues / Limitations (MVP scope)

- No automated test suite yet (Jest/Vitest) — testing so far is manual
  smoke-testing (backend syntax/import checks, a full `vite build`, and a
  live dev-server check). See the testing checklist below for what to verify
  manually before wider use.
- `CommunityOrganization` model exists but has no dedicated CRUD routes yet
  (kept minimal per "don't over-engineer" — add routes only if this becomes
  a real, separate workflow from resource submission).
- No password-reset flow (would need email sending infrastructure — out of
  scope for MVP).
- Only English strings are populated in the i18n dictionary; the structure
  supports more languages but none are translated yet.
- Real MongoDB + real browser testing hasn't been done in this environment
  (no MongoDB instance available here) — do this together locally next.

## Manual Testing Checklist

**Auth & RBAC**
- [ ] Register a new member account; confirm you're logged in immediately.
- [ ] Log out, log back in with correct/incorrect password (confirm generic error message either way).
- [ ] Trigger 5 failed logins; confirm the account locks for ~15 minutes.
- [ ] Confirm a `member` cannot reach `/admin` (redirects) and admin API routes return 403.
- [ ] Confirm the JWT cookie is httpOnly (check DevTools → Application → Cookies).

**Resources / Directory**
- [ ] Browse `/directory`, filter by category and cost, search a keyword.
- [ ] Open a resource; confirm the "Demo/sample data" note appears for seeded resources.
- [ ] Log in and submit a new resource; confirm it starts as "Community Submitted".
- [ ] As admin, verify or flag it from Admin → Pending Resources; confirm it appears correctly in the Directory afterward.

**Reports**
- [ ] Report a resource with a reason; confirm the resource flips to "Needs Review".
- [ ] As admin, resolve/dismiss the report from Admin → Reports.
- [ ] Confirm the report appears on the reporting user's Dashboard.

**Navigator / Emergency / Explain Simply**
- [ ] Walk through each Navigator option; confirm it lands on the right category or page.
- [ ] Visit `/emergency`; confirm the banner and configured contacts display.
- [ ] Search a term on `/explain-simply` (e.g. "hypertension").

**Accessibility**
- [ ] Toggle each accessibility option at `/accessibility` without logging in; confirm it persists after a refresh.

**Admin**
- [ ] View Overview stats, change a user's role, confirm you cannot change your own role.
- [ ] Check Audit Log shows entries for the actions above.

## Not In Scope (by design)

- Online medical diagnosis or prescription functionality
- Real-time features / WebSockets
- Payment processing
